using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using MCPServer.Models;
using MCPServer.Services;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using System.Collections.Concurrent;

namespace MCPServer
{
    public class MCPServerFunction
    {
        private readonly ILogger _logger;
        private readonly MCPService _mcpService;
        private static readonly ConcurrentDictionary<string, DateTime> _sessions = new();

        public MCPServerFunction(ILoggerFactory loggerFactory, MCPService mcpService)
        {
            _logger = loggerFactory.CreateLogger<MCPServerFunction>();
            _mcpService = mcpService;
        }

        [Function("ProcessPrompt")]
        public async Task<HttpResponseData> ProcessPrompt(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "prompt")] HttpRequestData req)
        {
            _logger.LogInformation("Processando prompt em linguagem natural.");

            try
            {
                // Lê o prompt do corpo da requisição
                string prompt = await new StreamReader(req.Body).ReadToEndAsync();
                
                if (string.IsNullOrEmpty(prompt))
                {
                    var errorResponse = req.CreateResponse(HttpStatusCode.BadRequest);
                    errorResponse.Headers.Add("Content-Type", "application/json");
                    await errorResponse.WriteStringAsync(JsonConvert.SerializeObject(new { error = "Prompt não pode estar vazio" }));
                    return errorResponse;
                }

                _logger.LogInformation($"Processando prompt: {prompt}");

                // Processa o prompt usando o process_question tool
                var callParams = new CallToolParams
                {
                    Name = "process_question",
                    Arguments = new Dictionary<string, object>
                    {
                        { "question", prompt }
                    }
                };

                var result = await _mcpService.CallTool(callParams);

                // Cria a resposta HTTP
                var httpResponse = req.CreateResponse(HttpStatusCode.OK);
                httpResponse.Headers.Add("Content-Type", "application/json");
                
                var responseJson = JsonConvert.SerializeObject(result, Formatting.Indented);
                await httpResponse.WriteStringAsync(responseJson);

                return httpResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao processar prompt");
                var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
                errorResponse.Headers.Add("Content-Type", "application/json");
                await errorResponse.WriteStringAsync(JsonConvert.SerializeObject(new { error = ex.Message }));
                return errorResponse;
            }
        }

        [Function("MCPServer")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", "options", "delete", Route = "mcp")] HttpRequestData req)
        {
            _logger.LogInformation($"MCP Server recebeu uma requisição {req.Method}.");

            try
            {
                // Handle OPTIONS requests for CORS
                if (req.Method.Equals("OPTIONS", StringComparison.OrdinalIgnoreCase))
                {
                    return HandleCORSRequest(req);
                }

                // Handle DELETE requests for session termination
                if (req.Method.Equals("DELETE", StringComparison.OrdinalIgnoreCase))
                {
                    return HandleSessionTermination(req);
                }

                // Handle GET requests for Server-Sent Events
                if (req.Method.Equals("GET", StringComparison.OrdinalIgnoreCase))
                {
                    return await HandleSSERequest(req);
                }

                // Handle POST requests (main MCP communication)
                if (req.Method.Equals("POST", StringComparison.OrdinalIgnoreCase))
                {
                    return await HandlePostRequest(req);
                }

                // Method not allowed
                var methodNotAllowed = req.CreateResponse(HttpStatusCode.MethodNotAllowed);
                await methodNotAllowed.WriteStringAsync("Method not allowed");
                return methodNotAllowed;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro interno do servidor");
                return await CreateErrorResponse(req, -32603, "Internal error", ex.Message);
            }
        }

        private async Task<HttpResponseData> HandlePostRequest(HttpRequestData req)
        {
            try
            {
                // Lê o corpo da requisição
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                
                if (string.IsNullOrEmpty(requestBody))
                {
                    return await CreateErrorResponse(req, -32600, "Invalid Request", "Request body is empty");
                }

                // Deserializa a requisição MCP
                var mcpRequest = JsonConvert.DeserializeObject<MCPRequest>(requestBody);
                
                if (mcpRequest == null || string.IsNullOrEmpty(mcpRequest.Method))
                {
                    return await CreateErrorResponse(req, -32600, "Invalid Request", "Invalid JSON-RPC request");
                }

                _logger.LogInformation($"Processando método: {mcpRequest.Method}");

                // Processa a requisição baseada no método
                var response = await ProcessMCPRequest(mcpRequest, req);

                // Cria a resposta HTTP
                var httpResponse = req.CreateResponse(HttpStatusCode.OK);
                httpResponse.Headers.Add("Content-Type", "application/json");
                httpResponse.Headers.Add("Access-Control-Allow-Origin", "*");
                httpResponse.Headers.Add("Access-Control-Allow-Headers", "Content-Type, Accept, Mcp-Session-Id, Authorization");
                
                // Adiciona session ID se for uma requisição de initialize
                if (mcpRequest.Method == "initialize" && response.Result != null)
                {
                    var sessionId = GenerateSessionId();
                    httpResponse.Headers.Add("Mcp-Session-Id", sessionId);
                    _sessions[sessionId] = DateTime.UtcNow;
                    _logger.LogInformation($"Nova sessão criada: {sessionId}");
                }
                
                var responseJson = JsonConvert.SerializeObject(response, Formatting.Indented);
                await httpResponse.WriteStringAsync(responseJson);

                return httpResponse;
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "Erro ao deserializar JSON");
                return await CreateErrorResponse(req, -32700, "Parse error", ex.Message);
            }
        }

        private HttpResponseData HandleSessionTermination(HttpRequestData req)
        {
            var sessionId = GetSessionId(req);
            if (!string.IsNullOrEmpty(sessionId) && _sessions.TryRemove(sessionId, out _))
            {
                _logger.LogInformation($"Sessão terminada: {sessionId}");
            }

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }

        private string GenerateSessionId()
        {
            return Guid.NewGuid().ToString("N")[..16]; // 16 caracteres hexadecimais
        }

        private string? GetSessionId(HttpRequestData req)
        {
            if (req.Headers.TryGetValues("Mcp-Session-Id", out var values))
            {
                return values.FirstOrDefault();
            }
            return null;
        }

        private async Task<MCPResponse> ProcessMCPRequest(MCPRequest request, HttpRequestData req)
        {
            var response = new MCPResponse { Id = request.Id };
            var sessionId = GetSessionId(req);

            // Valida sessão para métodos que não sejam initialize
            if (request.Method != "initialize" && !string.IsNullOrEmpty(sessionId))
            {
                if (!_sessions.ContainsKey(sessionId))
                {
                    response.Error = new MCPError
                    {
                        Code = -32002,
                        Message = "Invalid session",
                        Data = "Session not found or expired"
                    };
                    return response;
                }
                // Atualiza timestamp da sessão
                _sessions[sessionId] = DateTime.UtcNow;
            }

            try
            {
                switch (request.Method)
                {
                    case "initialize":
                        var initParams = JsonConvert.DeserializeObject<InitializeParams>(request.Params?.ToString() ?? "{}");
                        response.Result = _mcpService.Initialize(initParams ?? new InitializeParams());
                        break;

                    case "initialized":
                        // Notificação de que o cliente foi inicializado
                        response.Result = new { };
                        break;

                    case "tools/list":
                        response.Result = _mcpService.ListTools();
                        break;

                    case "tools/call":
                        var callParams = JsonConvert.DeserializeObject<CallToolParams>(request.Params?.ToString() ?? "{}");
                        response.Result = await _mcpService.CallTool(callParams ?? new CallToolParams());
                        break;

                    case "resources/list":
                        response.Result = _mcpService.ListResources();
                        break;

                    case "resources/read":
                        var readParams = JsonConvert.DeserializeObject<ReadResourceParams>(request.Params?.ToString() ?? "{}");
                        response.Result = await _mcpService.ReadResource(readParams ?? new ReadResourceParams());
                        break;

                    case "prompts/list":
                        response.Result = _mcpService.ListPrompts();
                        break;

                    case "prompts/get":
                        var promptParams = JsonConvert.DeserializeObject<GetPromptParams>(request.Params?.ToString() ?? "{}");
                        response.Result = _mcpService.GetPrompt(promptParams ?? new GetPromptParams());
                        break;

                    default:
                        response.Error = new MCPError
                        {
                            Code = -32601,
                            Message = "Method not found",
                            Data = $"Método '{request.Method}' não é suportado"
                        };
                        break;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao processar método {request.Method}");
                response.Error = new MCPError
                {
                    Code = -32603,
                    Message = "Internal error",
                    Data = ex.Message
                };
            }

            return response;
        }

        private async Task<HttpResponseData> CreateErrorResponse(HttpRequestData req, int code, string message, string? data = null)
        {
            var errorResponse = new MCPResponse
            {
                Error = new MCPError
                {
                    Code = code,
                    Message = message,
                    Data = data
                }
            };

            var httpResponse = req.CreateResponse(HttpStatusCode.BadRequest);
            httpResponse.Headers.Add("Content-Type", "application/json");
            
            var responseJson = JsonConvert.SerializeObject(errorResponse, Formatting.Indented);
            await httpResponse.WriteStringAsync(responseJson);

            return httpResponse;
        }

        private async Task<HttpResponseData> HandleSSERequest(HttpRequestData req)
        {
            _logger.LogInformation("Handling SSE request for MCP");

            // Check if client accepts text/event-stream
            var acceptHeader = req.Headers.GetValues("Accept").FirstOrDefault();
            if (acceptHeader == null || !acceptHeader.Contains("text/event-stream"))
            {
                var errorResponse = req.CreateResponse(HttpStatusCode.MethodNotAllowed);
                await errorResponse.WriteStringAsync("SSE not supported without proper Accept header");
                return errorResponse;
            }

            // Valida sessão se fornecida
            var sessionId = GetSessionId(req);
            if (!string.IsNullOrEmpty(sessionId))
            {
                if (!_sessions.ContainsKey(sessionId))
                {
                    var errorResponse = req.CreateResponse(HttpStatusCode.Unauthorized);
                    await errorResponse.WriteStringAsync("Invalid or expired session");
                    return errorResponse;
                }
                // Atualiza timestamp da sessão
                _sessions[sessionId] = DateTime.UtcNow;
            }

            // Create SSE response
            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "text/event-stream");
            response.Headers.Add("Cache-Control", "no-cache");
            response.Headers.Add("Connection", "keep-alive");
            response.Headers.Add("X-Accel-Buffering", "no");
            response.Headers.Add("Access-Control-Allow-Origin", "*");
            response.Headers.Add("Access-Control-Allow-Headers", "Content-Type, Accept, Mcp-Session-Id, Authorization");
            response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
            response.Headers.Add("Access-Control-Expose-Headers", "Mcp-Session-Id");

            // Adiciona session ID se fornecido
            if (!string.IsNullOrEmpty(sessionId))
            {
                response.Headers.Add("Mcp-Session-Id", sessionId);
            }

            // Send initial SSE message to keep connection alive
            var sseMessage = "data: {\"jsonrpc\":\"2.0\",\"method\":\"notifications/initialized\",\"params\":{}}\n\n";
            await response.WriteStringAsync(sseMessage);

            return response;
        }

        private HttpResponseData HandleCORSRequest(HttpRequestData req)
        {
            _logger.LogInformation("Handling CORS preflight request");

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Access-Control-Allow-Origin", "*");
            response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
            response.Headers.Add("Access-Control-Allow-Headers", "Content-Type, Accept, Mcp-Session-Id, Authorization");
            response.Headers.Add("Access-Control-Expose-Headers", "Mcp-Session-Id");
            response.Headers.Add("Access-Control-Max-Age", "86400");

            return response;
        }
    }
}