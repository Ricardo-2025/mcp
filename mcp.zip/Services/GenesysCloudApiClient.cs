using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MCPServer.Models.Genesys;

namespace MCPServer.Services
{
    public class GenesysCloudApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<GenesysCloudApiClient> _logger;
        private string? _accessToken;
        private DateTime _tokenExpiration;
        private readonly string _clientId;
        private readonly string _clientSecret;
        private readonly string _environment;
        private readonly string _authUrl;
        private readonly int _tokenExpirationBuffer;

        public GenesysCloudApiClient(HttpClient httpClient, IConfiguration configuration, ILogger<GenesysCloudApiClient> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;

            _clientId = _configuration["GenesysCloud:ClientId"] ?? throw new ArgumentException("GenesysCloud:ClientId não configurado");
            _clientSecret = _configuration["GenesysCloud:ClientSecret"] ?? throw new ArgumentException("GenesysCloud:ClientSecret não configurado");
            _environment = _configuration["GenesysCloud:ApiUrl"] ?? _configuration["GenesysCloud:Environment"] ?? "https://api.mypurecloud.com";
            _authUrl = _configuration["GenesysCloud:AuthUrl"] ?? "https://login.mypurecloud.com/oauth/token";
            _tokenExpirationBuffer = int.Parse(_configuration["GenesysCloud:TokenExpirationBuffer"] ?? "300");
        }

        private async Task<string> GetAccessTokenAsync()
        {
            if (!string.IsNullOrEmpty(_accessToken) && DateTime.UtcNow < _tokenExpiration.AddSeconds(-_tokenExpirationBuffer))
            {
                return _accessToken;
            }

            try
            {
                var authString = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_clientId}:{_clientSecret}"));
                var request = new HttpRequestMessage(HttpMethod.Post, _authUrl);
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", authString);
                request.Content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "client_credentials")
                });

                var response = await _httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                var responseContent = await response.Content.ReadAsStringAsync();
                _logger.LogDebug("Resposta OAuth2: {ResponseContent}", responseContent);

                var tokenResponse = JsonSerializer.Deserialize<TokenResponse>(responseContent);

                if (tokenResponse?.AccessToken == null)
                {
                    _logger.LogError("Token de acesso não recebido. Resposta: {ResponseContent}", responseContent);
                    throw new Exception($"Token de acesso não recebido. Resposta da API: {responseContent}");
                }

                _accessToken = tokenResponse.AccessToken;
                _tokenExpiration = DateTime.UtcNow.AddSeconds(tokenResponse.ExpiresIn);

                _logger.LogInformation("Token OAuth2 obtido com sucesso. Expira em: {ExpirationTime}", _tokenExpiration);
                return _accessToken;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao obter token OAuth2");
                throw new Exception($"Falha na autenticação OAuth2: {ex.Message}", ex);
            }
        }

        public async Task<string> GetAsync(string endpoint)
        {
            return await ExecuteWithRetryAsync(async () =>
            {
                var token = await GetAccessTokenAsync();
                var request = new HttpRequestMessage(HttpMethod.Get, $"{_environment}{endpoint}");
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    // Token pode ter expirado, forçar renovação
                    _accessToken = null;
                    _tokenExpiration = DateTime.MinValue;
                    token = await GetAccessTokenAsync();
                    request = new HttpRequestMessage(HttpMethod.Get, $"{_environment}{endpoint}");
                    request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                    response = await _httpClient.SendAsync(request);
                }

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError("Erro na API do Genesys Cloud. Status: {StatusCode}, Conteúdo: {Content}", response.StatusCode, errorContent);
                    throw new Exception($"Erro na API do Genesys Cloud: {response.StatusCode} - {errorContent}");
                }

                return await response.Content.ReadAsStringAsync();
            });
        }

        public async Task<string> PostAsync(string endpoint, object data)
        {
            return await ExecuteWithRetryAsync(async () =>
            {
                var token = await GetAccessTokenAsync();
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_environment}{endpoint}");
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                request.Content = new StringContent(JsonSerializer.Serialize(data), Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    // Token pode ter expirado, forçar renovação
                    _accessToken = null;
                    _tokenExpiration = DateTime.MinValue;
                    token = await GetAccessTokenAsync();
                    request = new HttpRequestMessage(HttpMethod.Post, $"{_environment}{endpoint}");
                    request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                    request.Content = new StringContent(JsonSerializer.Serialize(data), Encoding.UTF8, "application/json");
                    response = await _httpClient.SendAsync(request);
                }

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError("Erro na API do Genesys Cloud. Status: {StatusCode}, Conteúdo: {Content}", response.StatusCode, errorContent);
                    throw new Exception($"Erro na API do Genesys Cloud: {response.StatusCode} - {errorContent}");
                }

                return await response.Content.ReadAsStringAsync();
            });
        }

        private async Task<T> ExecuteWithRetryAsync<T>(Func<Task<T>> operation)
        {
            const int maxRetryAttempts = 3;
            const int baseRetryDelayMs = 1000;

            for (int attempt = 0; attempt <= maxRetryAttempts; attempt++)
            {
                try
                {
                    return await operation();
                }
                catch (HttpRequestException ex) when (attempt < maxRetryAttempts)
                {
                    var delay = baseRetryDelayMs * (int)Math.Pow(2, attempt);
                    _logger.LogWarning(ex, "Tentativa {Attempt} de {MaxAttempts} falhou. Tentando novamente em {Delay}ms",
                        attempt + 1, maxRetryAttempts + 1, delay);

                    await Task.Delay(delay);
                }
                catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException && attempt < maxRetryAttempts)
                {
                    var delay = baseRetryDelayMs * (int)Math.Pow(2, attempt);
                    _logger.LogWarning(ex, "Timeout na tentativa {Attempt} de {MaxAttempts}. Tentando novamente em {Delay}ms",
                        attempt + 1, maxRetryAttempts + 1, delay);

                    await Task.Delay(delay);
                }
                catch (Exception ex) when (IsTransientError(ex) && attempt < maxRetryAttempts)
                {
                    var delay = baseRetryDelayMs * (int)Math.Pow(2, attempt);
                    _logger.LogWarning(ex, "Erro transiente na tentativa {Attempt} de {MaxAttempts}. Tentando novamente em {Delay}ms",
                        attempt + 1, maxRetryAttempts + 1, delay);

                    await Task.Delay(delay);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Erro na operação após {Attempts} tentativas", attempt + 1);
                    throw;
                }
            }

            throw new InvalidOperationException("Não deveria chegar aqui");
        }

        private static bool IsTransientError(Exception ex)
        {
            return ex is HttpRequestException ||
                   ex is TaskCanceledException ||
                   (ex is System.Net.Sockets.SocketException) ||
                   (ex.Message?.Contains("timeout", StringComparison.OrdinalIgnoreCase) == true) ||
                   (ex.Message?.Contains("connection", StringComparison.OrdinalIgnoreCase) == true);
        }

        // Métodos específicos para APIs do Genesys Cloud
        public async Task<string> GetUsersAsync(int pageSize = 25, int pageNumber = 1)
        {
            var endpoint = $"/api/v2/users?pageSize={pageSize}&pageNumber={pageNumber}";
            return await GetAsync(endpoint);
        }

        public async Task<string?> GetUsersAsync(string? email = null)
        {
            try
            {
                var endpoint = "/api/v2/users?pageSize=100";
                if (!string.IsNullOrEmpty(email))
                {
                    endpoint += $"&email={Uri.EscapeDataString(email)}";
                }

                var response = await GetAsync(endpoint);
                return response;
                //    JsonSerializer.Deserialize<UsersResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar usuários");
                return null;
            }
        }

        public async Task<UserPresenceResponse?> GetUserPresenceAsync(string userId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/users/{userId}/presences/purecloud");
                return JsonSerializer.Deserialize<UserPresenceResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar presença do usuário {UserId}", userId);
                return null;
            }
        }

        public async Task<string> GetQueueMembersAsync(string queueId)
        {
            var endpoint = $"/api/v2/routing/queues/{queueId}/members";
            return await GetAsync(endpoint);
        }

        public async Task<string> PostAnalyticsQueryAsync(object queryData)
        {
            var endpoint = "/api/v2/analytics/conversations/details/query";
            return await PostAsync(endpoint, queryData);
        }

        public async Task<object?> GetAnalyticsDataAsync(DateTime startDate, DateTime endDate, string? metricsType)
        {
            try
            {
                var queryData = new
                {
                    interval = $"{startDate:yyyy-MM-ddTHH:mm:ss.fffZ}/{endDate:yyyy-MM-ddTHH:mm:ss.fffZ}",
                    granularity = "PT30M",
                    timeZone = "UTC",
                    groupBy = new[] { "queueId", "userId" },
                    metrics = metricsType?.ToLower() switch
                    {
                        "performance" => new[] { "nOffered", "tAnswered", "tAbandon", "tAcd" },
                        "volume" => new[] { "nOffered", "nAnswered", "nTransferred" },
                        "quality" => new[] { "tAcd", "tAcw", "tHandle" },
                        _ => new[] { "nOffered", "nAnswered", "tAnswered", "tAbandon", "tAcd", "tHandle" }
                    },
                    filter = new
                    {
                        type = "and",
                        clauses = new object[]
                        {
                            new
                            {
                                type = "or",
                                predicates = new object[]
                                {
                                    new { dimension = "mediaType", value = "voice" }
                                }
                            }
                        }
                    }
                };

                var response = await PostAnalyticsQueryAsync(queryData);
                var analyticsResult = JsonSerializer.Deserialize<object>(response);

                return new
                {
                    period = new { start = startDate, end = endDate },
                    metrics_type = metricsType ?? "all",
                    data = analyticsResult,
                    generated_at = DateTime.UtcNow
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar dados de analytics");
                return null;
            }
        }

        public async Task<string?> GetRoutingStatsAsync()
        {
            try
            {
                // Buscar estatísticas de roteamento usando a API de analytics
                var endDate = DateTime.UtcNow;
                var startDate = endDate.AddDays(-6); // Últimas 24 horas

                var queryData = new
                {
                    interval = $"{startDate:yyyy-MM-ddTHH:mm:ss.fffZ}/{endDate:yyyy-MM-ddTHH:mm:ss.fffZ}",
                    granularity = "PT1H",
                    timeZone = "UTC",
                    metrics = new[] { "nOffered", "nAnswered", "tAnswered", "nTransferred" },
                    groupBy = new[] { "queueId" }
                };

                var response = await PostAnalyticsQueryAsync(queryData);
                var routingData = response;
                    //JsonSerializer.Deserialize<string>(response);

                return routingData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar estatísticas de roteamento");
                return null;
            }
        }

        public async Task<object?> GetQueueStatsAsync(string queueId)
        {
            try
            {
                var endpoint = $"/api/v2/routing/queues/{queueId}/members";
                var response = await GetAsync(endpoint);
                var membersData = JsonSerializer.Deserialize<object>(response);

                return new
                {
                    queue_id = queueId,
                    members_data = membersData,
                    retrieved_at = DateTime.UtcNow
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar estatísticas da fila {QueueId}", queueId);
                return null;
            }
        }

        public async Task<UserSkillsResponse?> GetUserSkillsAsync(string userId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/users/{userId}/routingskills");
                return JsonSerializer.Deserialize<UserSkillsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar skills do usuário {UserId}", userId);
                return null;
            }
        }

        public async Task<User?> GetUserByIdAsync(string userId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/users/{userId}");
                return JsonSerializer.Deserialize<User>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar usuário {UserId}", userId);
                return null;
            }
        }

        public async Task<string?> GetQueuesAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/routing/queues?pageSize=100");
                return response;
                //    JsonSerializer.Deserialize<QueuesResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar filas");
                return null;
            }
        }

        public async Task<Queue?> GetQueueByIdAsync(string queueId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/routing/queues/{queueId}");
                return JsonSerializer.Deserialize<Queue>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar fila {QueueId}", queueId);
                return null;
            }
        }

        public async Task<string?> GetSkillsAsync(string? name = null)
        {
            try
            {
                var endpoint = "/api/v2/routing/skills?pageSize=100";
                if (!string.IsNullOrEmpty(name))
                {
                    endpoint += $"&name={Uri.EscapeDataString(name)}";
                }

                var response = await GetAsync(endpoint);
                return response;
                //    JsonSerializer.Deserialize<SkillsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar skills");
                return null;
            }
        }

        public async Task<Skill?> GetSkillByIdAsync(string skillId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/routing/skills/{skillId}");
                return JsonSerializer.Deserialize<Skill>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar skill {SkillId}", skillId);
                return null;
            }
        }

        // Métodos para Campaigns
        public async Task<string?> GetCampaignsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/outbound/campaigns?pageSize=100");
                return response;

                //    JsonSerializer.Deserialize<string>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar campanhas");
                return null;
            }
        }

        public async Task<Campaign?> GetCampaignByIdAsync(string campaignId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/outbound/campaigns/{campaignId}");
                return JsonSerializer.Deserialize<Campaign>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar campanha {CampaignId}", campaignId);
                return null;
            }
        }

        public async Task<CampaignStatsResponse?> GetCampaignStatsAsync(string campaignId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/outbound/campaigns/{campaignId}/stats");
                return JsonSerializer.Deserialize<CampaignStatsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar estatísticas da campanha {CampaignId}", campaignId);
                return null;
            }
        }

        // Métodos para Integrations
        public async Task<string?> GetIntegrationsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/integrations?pageSize=100");
                return response;
                //    JsonSerializer.Deserialize<IntegrationsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar integrações");
                return null;
            }
        }

        // APIs de Configuração Organizacional para Migração
        public async Task<string?> GetDivisionsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/authorization/divisions");
                return response;
                //    JsonSerializer.Deserialize<DivisionsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar divisões");
                return null;
            }
        }

        public async Task<LocationsResponse?> GetLocationsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/locations");
                return JsonSerializer.Deserialize<LocationsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar localizações");
                return null;
            }
        }

        public async Task<string?> GetGroupsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/groups");
                return response;
                //    JsonSerializer.Deserialize<GroupsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar grupos");
                return null;
            }
        }

        public async Task<string?> GetRolesAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/authorization/roles");
                return response;
                //    JsonSerializer.Deserialize<RolesResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar roles");
                return null;
            }
        }

        public async Task<string?> GetWrapupCodesAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/routing/wrapupcodes");
                return response;
                //    JsonSerializer.Deserialize<WrapupCodesResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar wrap-up codes");
                return null;
            }
        }

        public async Task<string?> GetOrganizationAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/organizations/me");
                return response;
                //    JsonSerializer.Deserialize<OrganizationResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar organização");
                return null;
            }
        }

        public async Task<string?> GetScriptsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/scripts");
                return response;
                //    JsonSerializer.Deserialize<ScriptsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar scripts");
                return null;
            }
        }

        public async Task<Integration?> GetIntegrationByIdAsync(string integrationId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/integrations/{integrationId}");
                return JsonSerializer.Deserialize<Integration>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar integração {IntegrationId}", integrationId);
                return null;
            }
        }

        public async Task<IntegrationTypesResponse?> GetIntegrationTypesAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/integrations/types?pageSize=100");
                return JsonSerializer.Deserialize<IntegrationTypesResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar tipos de integração");
                return null;
            }
        }

        // Métodos aprimorados para Analytics
        public async Task<ConversationDetailsResponse?> GetConversationDetailsAsync(DateTime startDate, DateTime endDate, string? filter = null)
        {
            try
            {
                var queryData = new
                {
                    interval = $"{startDate:yyyy-MM-ddTHH:mm:ss.fffZ}/{endDate:yyyy-MM-ddTHH:mm:ss.fffZ}",
                    paging = new { pageSize = 100, pageNumber = 1 },
                    segmentFilters = filter != null ? new[] { new { type = "and", predicates = new[] { new { dimension = "purpose", value = filter } } } } : null
                };

                var response = await PostAsync("/api/v2/analytics/conversations/details/query", queryData);
                return JsonSerializer.Deserialize<ConversationDetailsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar detalhes de conversas");
                return null;
            }
        }

        public async Task<QueueObservationResponse?> GetQueueObservationsAsync(DateTime startDate, DateTime endDate)
        {
            try
            {
                var queryData = new
                {
                    filter = new
                    {
                        type = "and",
                        clauses = new[]
                        {
                            new
                            {
                                type = "or",
                                predicates = new[]
                                {
                                    new { dimension = "queueId", value = "*" }
                                }
                            }
                        }
                    },
                    granularity = "PT30M",
                    groupBy = new[] { "queueId" },
                    metrics = new[] { "oWaiting", "oInteracting", "oOnQueueUsers", "oOffQueueUsers" },
                    detailMetrics = new[] { "oWaiting", "oInteracting" }
                };

                var response = await PostAsync("/api/v2/analytics/queues/observations/query", queryData);
                return JsonSerializer.Deserialize<QueueObservationResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar observações de filas");
                return null;
            }
        }

        // APIs do Architect para migração
        public async Task<string?> GetArchitectPromptsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/architect/prompts?pageSize=100");
                return response;
                //    JsonSerializer.Deserialize<PromptsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar prompts do Architect");
                return null;
            }
        }

        public async Task<string?> GetArchitectFlowsAsync(string? type = null)
        {
            try
            {
                var endpoint = "/api/v2/flows?pageSize=100";
                if (!string.IsNullOrEmpty(type))
                {
                    endpoint += $"&type={Uri.EscapeDataString(type)}";
                }

                var response = await GetAsync(endpoint);
                return response;
                //    JsonSerializer.Deserialize<FlowsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar fluxos do Architect");
                return null;
            }
        }

        public async Task<DependenciesResponse?> GetArchitectDependenciesAsync(string objectType, string objectId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/architect/dependencytracking/object?objectType={objectType}&objectId={objectId}");
                return JsonSerializer.Deserialize<DependenciesResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar dependências do Architect para {ObjectType}:{ObjectId}", objectType, objectId);
                return null;
            }
        }

        public async Task<SystemPromptsResponse?> GetArchitectSystemPromptsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/architect/systemprompts?pageSize=100");
                return JsonSerializer.Deserialize<SystemPromptsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar prompts do sistema do Architect");
                return null;
            }
        }

        // APIs de Workforce Management
        public async Task<string?> GetWorkforceManagementUnitsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/workforcemanagement/managementunits?pageSize=100");
                return response;
                //    JsonSerializer.Deserialize<ManagementUnitsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar unidades de gerenciamento WFM");
                return null;
            }
        }

        public async Task<SchedulesResponse?> GetWorkforceSchedulesAsync(string managementUnitId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/workforcemanagement/managementunits/{managementUnitId}/schedules?pageSize=100");
                return JsonSerializer.Deserialize<SchedulesResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar schedules WFM para unidade {ManagementUnitId}", managementUnitId);
                return null;
            }
        }

        public async Task<AdherenceResponse?> GetWorkforceAdherenceAsync(string managementUnitId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/workforcemanagement/managementunits/{managementUnitId}/adherence?pageSize=100");
                return JsonSerializer.Deserialize<AdherenceResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar adherence WFM para unidade {ManagementUnitId}", managementUnitId);
                return null;
            }
        }

        public async Task<ForecastsResponse?> GetWorkforceForecastsAsync(string managementUnitId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/workforcemanagement/managementunits/{managementUnitId}/forecasts?pageSize=100");
                return JsonSerializer.Deserialize<ForecastsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar forecasts WFM para unidade {ManagementUnitId}", managementUnitId);
                return null;
            }
        }

        public async Task<TimeOffRequestsResponse?> GetWorkforceTimeOffRequestsAsync(string managementUnitId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/workforcemanagement/managementunits/{managementUnitId}/timeoffrequests?pageSize=100");
                return JsonSerializer.Deserialize<TimeOffRequestsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar time off requests WFM para unidade {ManagementUnitId}", managementUnitId);
                return null;
            }
        }

        // Quality Management APIs
        public async Task<QualityEvaluationsResponse?> GetQualityEvaluationsAsync(string? agentId = null, string? evaluatorId = null, string? startDate = null, string? endDate = null)
        {
            try
            {
                var queryParams = new List<string>();
                if (!string.IsNullOrEmpty(agentId)) queryParams.Add($"agentUserId={agentId}");
                if (!string.IsNullOrEmpty(evaluatorId)) queryParams.Add($"evaluatorUserId={evaluatorId}");
                if (!string.IsNullOrEmpty(startDate)) queryParams.Add($"startTime={startDate}");
                if (!string.IsNullOrEmpty(endDate)) queryParams.Add($"endTime={endDate}");
                queryParams.Add("pageSize=100");

                var queryString = queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : "";
                var response = await GetAsync($"/api/v2/quality/evaluations/query{queryString}");
                return JsonSerializer.Deserialize<QualityEvaluationsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar avaliações de qualidade");
                return null;
            }
        }

        public async Task<string?> GetQualityFormsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/quality/forms/evaluations?pageSize=100");
                return response;
                //    JsonSerializer.Deserialize<QualityFormsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar formulários de qualidade");
                return null;
            }
        }

        public async Task<QualityCalibrationsResponse?> GetQualityCalibrationsAsync(string? calibratorId = null, string? startDate = null, string? endDate = null)
        {
            try
            {
                var queryParams = new List<string>();
                if (!string.IsNullOrEmpty(calibratorId)) queryParams.Add($"calibratorId={calibratorId}");
                if (!string.IsNullOrEmpty(startDate)) queryParams.Add($"startTime={startDate}");
                if (!string.IsNullOrEmpty(endDate)) queryParams.Add($"endTime={endDate}");
                queryParams.Add("pageSize=100");

                var queryString = queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : "";
                var response = await GetAsync($"/api/v2/quality/calibrations{queryString}");
                return JsonSerializer.Deserialize<QualityCalibrationsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar calibrações de qualidade");
                return null;
            }
        }

        // Conversations APIs
        public async Task<ConversationsResponse?> GetConversationsAsync(string? startDate = null, string? endDate = null, string? mediaType = null)
        {
            try
            {
                var queryParams = new List<string>();
                if (!string.IsNullOrEmpty(startDate)) queryParams.Add($"startTime={startDate}");
                if (!string.IsNullOrEmpty(endDate)) queryParams.Add($"endTime={endDate}");
                if (!string.IsNullOrEmpty(mediaType)) queryParams.Add($"mediaType={mediaType}");
                queryParams.Add("pageSize=100");

                var queryString = queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : "";
                var response = await GetAsync($"/api/v2/conversations{queryString}");
                return JsonSerializer.Deserialize<ConversationsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar conversas");
                return null;
            }
        }

        public async Task<ConversationDetailsResponse?> GetConversationDetailsAsync(string conversationId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/conversations/{conversationId}");
                return JsonSerializer.Deserialize<ConversationDetailsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar detalhes da conversa {ConversationId}", conversationId);
                return null;
            }
        }

        public async Task<ConversationMetricsResponse?> GetConversationMetricsAsync(string? startDate = null, string? endDate = null, string? queueId = null)
        {
            try
            {
                var queryParams = new List<string>();
                if (!string.IsNullOrEmpty(startDate)) queryParams.Add($"startTime={startDate}");
                if (!string.IsNullOrEmpty(endDate)) queryParams.Add($"endTime={endDate}");
                if (!string.IsNullOrEmpty(queueId)) queryParams.Add($"queueId={queueId}");
                queryParams.Add("pageSize=100");

                var queryString = queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : "";
                var response = await GetAsync($"/api/v2/conversations/aggregates/query{queryString}");
                return JsonSerializer.Deserialize<ConversationMetricsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar métricas de conversas");
                return null;
            }
        }

        // Recording APIs
        public async Task<RecordingsResponse?> GetRecordingsAsync(string? conversationId = null, string? startDate = null, string? endDate = null)
        {
            try
            {
                var queryParams = new List<string>();
                if (!string.IsNullOrEmpty(conversationId)) queryParams.Add($"conversationId={conversationId}");
                if (!string.IsNullOrEmpty(startDate)) queryParams.Add($"startTime={startDate}");
                if (!string.IsNullOrEmpty(endDate)) queryParams.Add($"endTime={endDate}");
                queryParams.Add("pageSize=100");

                var queryString = queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : "";
                var response = await GetAsync($"/api/v2/recordings{queryString}");
                return JsonSerializer.Deserialize<RecordingsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar gravações");
                return null;
            }
        }

        public async Task<RecordingMetadataResponse?> GetRecordingMetadataAsync(string recordingId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/recordings/{recordingId}/metadata");
                return JsonSerializer.Deserialize<RecordingMetadataResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar metadados da gravação {RecordingId}", recordingId);
                return null;
            }
        }

        public async Task<RecordingTranscriptionResponse?> GetRecordingTranscriptionAsync(string recordingId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/recordings/{recordingId}/transcription");
                return JsonSerializer.Deserialize<RecordingTranscriptionResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar transcrição da gravação {RecordingId}", recordingId);
                return null;
            }
        }

        // Outbound APIs
        public async Task<string?> GetOutboundCampaignsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/outbound/campaigns?pageSize=100");
                return response;
                //    JsonSerializer.Deserialize<OutboundCampaignsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar campanhas outbound");
                return null;
            }
        }

        public async Task<string?> GetContactListsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/outbound/contactlists?pageSize=100");
                return response;
                //    JsonSerializer.Deserialize<ContactListsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar listas de contatos");
                return null;
            }
        }

        public async Task<string?> GetOutboundSequencesAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/outbound/sequences?pageSize=100");
                return response;
                //    JsonSerializer.Deserialize<OutboundSequencesResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar sequências outbound");
                return null;
            }
        }

        // Analytics APIs
        public async Task<AnalyticsReportsResponse?> GetAnalyticsReportsAsync(string? startDate = null, string? endDate = null)
        {
            try
            {
                var queryParams = new List<string>();
                if (!string.IsNullOrEmpty(startDate))
                    queryParams.Add($"startDate={startDate}");
                if (!string.IsNullOrEmpty(endDate))
                    queryParams.Add($"endDate={endDate}");

                var queryString = queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : "";
                var response = await GetAsync($"/api/v2/analytics/reporting/reports{queryString}");
                return JsonSerializer.Deserialize<AnalyticsReportsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar relatórios de analytics");
                return null;
            }
        }

        public async Task<AnalyticsMetricsResponse?> GetAnalyticsMetricsAsync(string? interval = null)
        {
            try
            {
                var queryString = !string.IsNullOrEmpty(interval) ? $"?interval={interval}" : "";
                var response = await GetAsync($"/api/v2/analytics/reporting/metrics{queryString}");
                return JsonSerializer.Deserialize<AnalyticsMetricsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar métricas de analytics");
                return null;
            }
        }

        public async Task<AnalyticsDataResponse?> GetAnalyticsDataAsync(string reportId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/analytics/reporting/reports/{reportId}/data");
                return JsonSerializer.Deserialize<AnalyticsDataResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar dados de analytics");
                return null;
            }
        }

        public async Task<string?> GetPresenceDefinitionsAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/presencedefinitions");
                return response;
                //    JsonSerializer.Deserialize<PresenceDefinitionsResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar definições de presença");
                return null;
            }
        }
        public async Task<PresenceHistoryResponse?> GetPresenceHistoryAsync(string userId, DateTime? startDate = null, DateTime? endDate = null)
        {
            try
            {
                var queryParams = new List<string>();
                if (startDate.HasValue)
                    queryParams.Add($"startDate={startDate.Value:yyyy-MM-ddTHH:mm:ss.fffZ}");
                if (endDate.HasValue)
                    queryParams.Add($"endDate={endDate.Value:yyyy-MM-ddTHH:mm:ss.fffZ}");

                var queryString = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
                var response = await GetAsync($"/api/v2/users/{userId}/presences/purecloud/history{queryString}");
                return JsonSerializer.Deserialize<PresenceHistoryResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar histórico de presença");
                return null;
            }
        }

        public async Task<string?> GetGamificationProfilesAsync()
        {
            try
            {
                var response = await GetAsync("/api/v2/gamification/profiles");
                return response;
                //    JsonSerializer.Deserialize<GamificationProfilesResponse>(response, new JsonSerializerOptions
                //{
                //    PropertyNameCaseInsensitive = true
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar perfis de gamificação");
                return null;
            }
        }

        public async Task<GamificationMetricsResponse?> GetGamificationMetricsAsync(string profileId, DateTime? startDate = null, DateTime? endDate = null)
        {
            try
            {
                var queryParams = new List<string>();
                if (startDate.HasValue)
                    queryParams.Add($"startDate={startDate.Value:yyyy-MM-ddTHH:mm:ss.fffZ}");
                if (endDate.HasValue)
                    queryParams.Add($"endDate={endDate.Value:yyyy-MM-ddTHH:mm:ss.fffZ}");

                var queryString = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
                var response = await GetAsync($"/api/v2/gamification/profiles/{profileId}/metrics{queryString}");
                return JsonSerializer.Deserialize<GamificationMetricsResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar métricas de gamificação");
                return null;
            }
        }

        public async Task<GamificationLeaderboardResponse?> GetGamificationLeaderboardAsync(string profileId)
        {
            try
            {
                var response = await GetAsync($"/api/v2/gamification/profiles/{profileId}/leaderboard");
                return JsonSerializer.Deserialize<GamificationLeaderboardResponse>(response, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao buscar leaderboard de gamificação");
                return null;
            }
        }


    }
}
