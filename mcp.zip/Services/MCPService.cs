using MCPServer.Models;
using MCPServer.Models.Genesys;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace MCPServer.Services
{
    public class MCPService
    {
        private readonly List<Tool> _tools;
        private readonly List<Resource> _resources;
        private readonly List<Prompt> _prompts;
        private readonly ILogger<MCPService>? _logger;
        private readonly GenesysCloudApiClient? _genesysClient;

        public MCPService(ILogger<MCPService>? logger = null, GenesysCloudApiClient? genesysClient = null)
        {
            _logger = logger;
            _genesysClient = genesysClient;
            _tools = InitializeTools();
            _resources = InitializeResources();
            _prompts = InitializePrompts();
        }

        // Método auxiliar para formatação de dados de exportação
        private string FormatExportData(object data, string? format, string dataType)
        {
            return format?.ToLower() switch
            {
                "csv" => ConvertToCsv(data),
                "xml" => ConvertToXml(data),
                _ => System.Text.Json.JsonSerializer.Serialize(data, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
            };
        }

        private async Task<string> GetQueueRoutingInfoAsync(string? queueId, bool includeRules)
        {
            try
            {
                if (string.IsNullOrEmpty(queueId))
                {
                    return "❌ **Erro**: ID da fila é obrigatório para consulta de roteamento";
                }

                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var queue = await _genesysClient.GetQueueByIdAsync(queueId);
                if (queue == null)
                {
                    return $"❌ **Fila não encontrada**: ID {queueId}";
                }

                var routingInfo = $@"🎯 **Roteamento da Fila: {queue.Name}**

                🔹 **ID**: {queue.Id}
                🔹 **Status**: {(queue.State == "active" ? "Ativa" : "Inativa")}
                🔹 **Divisão**: {queue.Division?.Name ?? "N/A"}";

                if (includeRules && queue.RoutingRules != null)
                {
                    routingInfo += "\n\n📋 **Regras de Roteamento**:\n";
                    foreach (var rule in queue.RoutingRules)
                    {
                        routingInfo += $"• {rule}\n";
                    }
                }

                return routingInfo;
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao buscar roteamento da fila**: {ex.Message}";
            }
        }

        private async Task<string> GetSkillRoutingInfoAsync(string? skillId, bool includeRules)
        {
            try
            {
                if (string.IsNullOrEmpty(skillId))
                {
                    return "❌ **Erro**: ID da skill é obrigatório para consulta de roteamento";
                }

                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var skill = await _genesysClient.GetSkillByIdAsync(skillId);
                if (skill == null)
                {
                    return $"❌ **Skill não encontrada**: ID {skillId}";
                }

                return $@"🎪 **Roteamento da Skill: {skill.Name}**

                🔹 **ID**: {skill.Id}
                🔹 **Status**: {(skill.State == "active" ? "Ativa" : "Inativa")}
                🔹 **Criada em**: {skill.DateCreated?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}
                🔹 **Modificada em**: {skill.DateModified?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}";
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao buscar roteamento da skill**: {ex.Message}";
            }
        }

        private async Task<string> GetAgentRoutingInfoAsync(string? agentId, bool includeRules)
        {
            try
            {
                if (string.IsNullOrEmpty(agentId))
                {
                    return "❌ **Erro**: ID do agente é obrigatório para consulta de roteamento";
                }

                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var user = await _genesysClient.GetUserByIdAsync(agentId);
                if (user == null)
                {
                    return $"❌ **Agente não encontrado**: ID {agentId}";
                }

                var routingInfo = $@"👤 **Roteamento do Agente: {user.Name}**

                🔹 **ID**: {user.Id}
                🔹 **Email**: {user.Email ?? "N/A"}
                🔹 **Departamento**: {user.Department ?? "N/A"}
                🔹 **Status**: {(user.State == "active" ? "Ativo" : "Inativo")}";

                // Buscar skills do usuário se includeRules for true
                if (includeRules)
                {
                    try
                    {
                        var userSkills = await _genesysClient.GetUserSkillsAsync(agentId);
                        if (userSkills?.Entities != null && userSkills.Entities.Any())
                        {
                            routingInfo += "\n\n🎯 **Skills do Agente**:\n";
                            foreach (var skill in userSkills.Entities.Take(5))
                            {
                                routingInfo += $"• {skill.SkillName} (Nível: {skill.Proficiency})\n";
                            }
                        }
                    }
                    catch (Exception skillEx)
                    {
                        routingInfo += $"\n\n⚠️ **Erro ao buscar skills**: {skillEx.Message}";
                    }
                }

                return routingInfo;
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao buscar roteamento do agente**: {ex.Message}";
            }
        }

        public InitializeResult Initialize(InitializeParams initParams)
        {
            return new InitializeResult
            {
                ProtocolVersion = "2024-11-05",
                Capabilities = new ServerCapabilities
                {
                    Tools = new ToolsCapability { ListChanged = true },
                    Resources = new ResourcesCapability { Subscribe = false, ListChanged = true },
                    Prompts = new PromptsCapability { ListChanged = true }
                },
                ServerInfo = new ServerInfo
                {
                    Name = "MCP Server Azure Functions",
                    Version = "1.0.0"
                }
            };
        }

        public ListToolsResult ListTools()
        {
            return new ListToolsResult
            {
                Tools = _tools.ToArray()
            };
        }

        public async Task<CallToolResult> CallTool(CallToolParams callParams)
        {
            var tool = _tools.FirstOrDefault(t => t.Name == callParams.Name);
            if (tool == null)
            {
                return new CallToolResult
                {
                    IsError = true,
                    Content = new[]
                    {
                        new ToolContent
                        {
                            Type = "text",
                            Text = $"Tool '{callParams.Name}' não encontrado"
                        }
                    }
                };
            }

            try
            {
                var result = await ExecuteTool(callParams.Name, callParams.Arguments);
                return new CallToolResult
                {
                    IsError = false,
                    Content = new[]
                    {
                        new ToolContent
                        {
                            Type = "text",
                            Text = result
                        }
                    }
                };
            }
            catch (Exception ex)
            {
                return new CallToolResult
                {
                    IsError = true,
                    Content = new[]
                    {
                        new ToolContent
                        {
                            Type = "text",
                            Text = $"Erro ao executar tool: {ex.Message}"
                        }
                    }
                };
            }
        }

        public ListResourcesResult ListResources()
        {
            return new ListResourcesResult
            {
                Resources = _resources.ToArray()
            };
        }

        public async Task<ReadResourceResult> ReadResource(ReadResourceParams readParams)
        {
            var resource = _resources.FirstOrDefault(r => r.Uri == readParams.Uri);
            if (resource == null)
            {
                throw new Exception($"Resource '{readParams.Uri}' não encontrado");
            }

            try
            {
                var content = await GetResourceContent(readParams.Uri);
                return new ReadResourceResult
                {
                    Contents = new[]
                    {
                        new ResourceContent
                        {
                            Uri = readParams.Uri,
                            MimeType = resource.MimeType,
                            Text = content
                        }
                    }
                };
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao ler resource: {ex.Message}");
            }
        }

        public ListPromptsResult ListPrompts()
        {
            return new ListPromptsResult
            {
                Prompts = _prompts.ToArray()
            };
        }

        public GetPromptResult GetPrompt(GetPromptParams promptParams)
        {
            var prompt = _prompts.FirstOrDefault(p => p.Name == promptParams.Name);
            if (prompt == null)
            {
                throw new Exception($"Prompt '{promptParams.Name}' não encontrado");
            }

            var promptText = GeneratePromptText(promptParams.Name, promptParams.Arguments);

            return new GetPromptResult
            {
                Description = prompt.Description,
                Messages = new[]
                {
                    new PromptMessage
                    {
                        Role = "user",
                        Content = new PromptContent
                        {
                            Type = "text",
                            Text = promptText
                        }
                    }
                }
            };
        }

        private List<Tool> InitializeTools()
        {
            return new List<Tool>
            {
                new Tool
                {
                    Name = "inventory_users_genesys",
                    Description = "Inventário completo de usuários do Genesys Cloud para migração",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_inactive"] = new { type = "boolean", description = "Incluir usuários inativos", @default = false },
                            ["department_filter"] = new { type = "string", description = "Filtrar por departamento" }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "inventory_queues_genesys",
                    Description = "Inventário completo de filas do Genesys Cloud para migração",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_config"] = new { type = "boolean", description = "Incluir configurações detalhadas", @default = true },
                            ["include_sla"] = new { type = "boolean", description = "Incluir configurações de SLA", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "inventory_skills_genesys",
                    Description = "Inventário completo de skills do Genesys Cloud para migração",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_assignments"] = new { type = "boolean", description = "Incluir atribuições de skills aos agentes", @default = true },
                            ["category_filter"] = new { type = "string", description = "Filtrar por categoria" }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "inventory_routing_genesys",
                    Description = "Inventário completo de configurações de roteamento do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_rules"] = new { type = "boolean", description = "Incluir regras de roteamento detalhadas", @default = true },
                            ["include_rules"] = new { type = "boolean", description = "Incluir regras de roteamento", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "inventory_campaigns_genesys",
                    Description = "Inventário completo de campanhas outbound do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_inactive"] = new { type = "boolean", description = "Incluir campanhas inativas", @default = false },
                            ["campaign_type"] = new { type = "string", description = "Tipo de campanha (preview, progressive, predictive)" }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "inventory_analytics_genesys",
                    Description = "Inventário de relatórios e métricas históricas do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["date_range"] = new { type = "string", description = "Período dos dados (7d, 30d, 90d)", @default = "30d" },
                            ["metrics_type"] = new { type = "string", description = "Tipo de métricas (performance, volume, quality)" }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "inventory_integrations_genesys",
                    Description = "Inventário de integrações existentes no Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["integration_type"] = new { type = "string", description = "Tipo de integração (crm, telephony, chat, email)" },
                            ["include_config"] = new { type = "boolean", description = "Incluir configurações de integração", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                // Ferramentas de Configuração Organizacional para Migração
                new Tool
                {
                    Name = "config_divisions_genesys",
                    Description = "Exporta configurações de divisões organizacionais do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_object_counts"] = new { type = "boolean", description = "Incluir contagem de objetos por divisão", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "config_locations_genesys",
                    Description = "Exporta configurações de localizações/sites do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_addresses"] = new { type = "boolean", description = "Incluir endereços completos", @default = true },
                            ["include_emergency_info"] = new { type = "boolean", description = "Incluir informações de emergência", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "config_groups_genesys",
                    Description = "Exporta configurações de grupos de usuários do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_members"] = new { type = "boolean", description = "Incluir membros dos grupos", @default = true },
                            ["include_contacts"] = new { type = "boolean", description = "Incluir informações de contato", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "config_roles_genesys",
                    Description = "Exporta configurações de roles e permissões do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_permissions"] = new { type = "boolean", description = "Incluir lista detalhada de permissões", @default = true },
                            ["include_policies"] = new { type = "boolean", description = "Incluir políticas de permissão", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "config_wrapupcodes_genesys",
                    Description = "Exporta configurações de códigos de finalização (wrap-up codes) do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_division_info"] = new { type = "boolean", description = "Incluir informações da divisão", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "config_organization_genesys",
                    Description = "Exporta configurações gerais da organização do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_features"] = new { type = "boolean", description = "Incluir features habilitadas", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "config_scripts_genesys",
                    Description = "Exporta configurações de scripts de atendimento do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_versions"] = new { type = "boolean", description = "Incluir informações de versão", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "config_export_complete_genesys",
                    Description = "Exportação completa de todas as configurações organizacionais para migração",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_all_details"] = new { type = "boolean", description = "Incluir todos os detalhes disponíveis", @default = true },
                            ["compress_output"] = new { type = "boolean", description = "Comprimir saída em arquivo ZIP", @default = false }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                // Ferramentas do Architect para migração
                new Tool
                {
                    Name = "architect_prompts_genesys",
                    Description = "Exporta todos os prompts de usuário do Genesys Cloud Architect",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["include_resources"] = new { type = "boolean", description = "Incluir recursos de áudio/texto dos prompts", @default = true },
                            ["language_filter"] = new { type = "string", description = "Filtrar por idioma específico (pt-BR, en-US, es-ES)" }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                new Tool
                {
                    Name = "architect_flows_genesys",
                    Description = "Exporta configurações de fluxos do Genesys Cloud Architect (inbound, outbound, in-queue)",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                            ["flow_type"] = new { type = "string", description = "Tipo de fluxo (inboundcall, outboundcall, inqueuecall, all)", @default = "all" },
                            ["include_versions"] = new { type = "boolean", description = "Incluir informações de versões", @default = true },
                            ["published_only"] = new { type = "boolean", description = "Apenas fluxos publicados", @default = false }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                //new Tool
                //{
                //    Name = "architect_dependencies_genesys",
                //    Description = "Mapeia dependências entre recursos do Genesys Cloud Architect",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                //            ["object_type"] = new { type = "string", description = "Tipo de objeto (flow, prompt, queue, skill)", @default = "flow" },
                //            ["object_id"] = new { type = "string", description = "ID específico do objeto (opcional - se não fornecido, analisa todos)" },
                //            ["include_referenced"] = new { type = "boolean", description = "Incluir objetos referenciados", @default = true },
                //            ["include_referencing"] = new { type = "boolean", description = "Incluir objetos que fazem referência", @default = true }
                //        },
                //        Required = Array.Empty<string>()
                //    }
                //},
                //new Tool
                //{
                //    Name = "architect_systemprompts_genesys",
                //    Description = "Exporta prompts do sistema do Genesys Cloud Architect",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv, xml, excel)", @default = "json" },
                //            ["include_resources"] = new { type = "boolean", description = "Incluir recursos de áudio dos prompts", @default = true },
                //            ["language_filter"] = new { type = "string", description = "Filtrar por idioma específico (pt-BR, en-US, es-ES)" }
                //        },
                //        Required = Array.Empty<string>()
                //    }
                //},
                // Ferramentas de Workforce Management
                new Tool
                {
                    Name = "workforce_management_units_genesys",
                    Description = "Consulta unidades de gerenciamento de força de trabalho do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["unit_id"] = new { type = "string", description = "ID da unidade de gerenciamento (opcional - se não fornecido, lista todas)" },
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" },
                            ["include_settings"] = new { type = "boolean", description = "Incluir configurações da unidade", @default = true }
                        },
                        Required = Array.Empty<string>()
                    }
                },
                //new Tool
                //{
                //    Name = "workforce_schedules_genesys",
                //    Description = "Consulta cronogramas de trabalho do Genesys Cloud Workforce Management",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["unit_id"] = new { type = "string", description = "ID da unidade de gerenciamento" },
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" },
                //            ["agent_id"] = new { type = "string", description = "ID do agente específico (opcional)" }
                //        },
                //        Required = new[] { "unit_id" }
                //    }
                //},
                //new Tool
                //{
                //    Name = "workforce_adherence_genesys",
                //    Description = "Consulta dados de aderência de agentes do Genesys Cloud Workforce Management",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["unit_id"] = new { type = "string", description = "ID da unidade de gerenciamento" },
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" },
                //            ["agent_ids"] = new { type = "array", description = "Lista de IDs de agentes (opcional)" }
                //        },
                //        Required = new[] { "unit_id" }
                //    }
                //},
                //new Tool
                //{
                //    Name = "workforce_forecasts_genesys",
                //    Description = "Consulta previsões de demanda do Genesys Cloud Workforce Management",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["unit_id"] = new { type = "string", description = "ID da unidade de gerenciamento" },
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" },
                //            ["queue_ids"] = new { type = "array", description = "Lista de IDs de filas (opcional)" }
                //        },
                //        Required = new[] { "unit_id" }
                //    }
                //},
                //new Tool
                //{
                //    Name = "workforce_timeoff_genesys",
                //    Description = "Consulta solicitações de folga do Genesys Cloud Workforce Management",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["unit_id"] = new { type = "string", description = "ID da unidade de gerenciamento" },
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" },
                //            ["status"] = new { type = "string", description = "Status da solicitação (pending, approved, denied)" },
                //            ["agent_id"] = new { type = "string", description = "ID do agente específico (opcional)" }
                //        },
                //        Required = new[] { "unit_id" }
                //    }
                //},
                //new Tool
                //{
                //    Name = "quality_evaluations_genesys",
                //    Description = "Consulta avaliações de qualidade do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["agent_id"] = new { type = "string", description = "ID do agente avaliado (opcional)" },
                //            ["evaluator_id"] = new { type = "string", description = "ID do avaliador (opcional)" },
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { }
                //    }
                //},
                new Tool
                {
                    Name = "quality_forms_genesys",
                    Description = "Consulta formulários de avaliação de qualidade do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                        },
                        Required = new string[] { }
                    }
                },
                //new Tool
                //{
                //    Name = "quality_calibrations_genesys",
                //    Description = "Consulta calibrações de qualidade do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["calibrator_id"] = new { type = "string", description = "ID do calibrador (opcional)" },
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { }
                //    }
                //},
                //new Tool
                //{
                //    Name = "conversations_genesys",
                //    Description = "Consulta conversas do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["media_type"] = new { type = "string", description = "Tipo de mídia (voice, chat, email, callback, etc.)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { }
                //    }
                //},
                //new Tool
                //{
                //    Name = "conversation_details_genesys",
                //    Description = "Consulta detalhes de uma conversa específica do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["conversation_id"] = new { type = "string", description = "ID da conversa" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { "conversation_id" }
                //    }
                //},
                //new Tool
                //{
                //    Name = "conversation_metrics_genesys",
                //    Description = "Consulta métricas de conversas do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["queue_id"] = new { type = "string", description = "ID da fila (opcional)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { }
                //    }
                //},
                //new Tool
                //{
                //    Name = "recordings_genesys",
                //    Description = "Consulta gravações do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["conversation_id"] = new { type = "string", description = "ID da conversa (opcional)" },
                //            ["start_date"] = new { type = "string", description = "Data de início (formato: YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (formato: YYYY-MM-DD)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { }
                //    }
                //},
                //new Tool
                //{
                //    Name = "recording_metadata_genesys",
                //    Description = "Consulta metadados de uma gravação específica do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["recording_id"] = new { type = "string", description = "ID da gravação" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { "recording_id" }
                //    }
                //},
                //new Tool
                //{
                //    Name = "recording_transcription_genesys",
                //    Description = "Consulta transcrição de uma gravação específica do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["recording_id"] = new { type = "string", description = "ID da gravação" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { "recording_id" }
                //    }
                //},
                new Tool
                {
                    Name = "outbound_campaigns_genesys",
                    Description = "Consulta campanhas outbound do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                        },
                        Required = new string[] { }
                    }
                },
                new Tool
                {
                    Name = "contact_lists_genesys",
                    Description = "Consulta listas de contatos do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                        },
                        Required = new string[] { }
                    }
                },
                new Tool
                {
                    Name = "outbound_sequences_genesys",
                    Description = "Consulta sequências outbound do Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                        },
                        Required = new string[] { }
                    }
                },
                //new Tool
                //{
                //    Name = "analytics_reports_genesys",
                //    Description = "Consulta relatórios de analytics do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["start_date"] = new { type = "string", description = "Data de início (YYYY-MM-DD)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (YYYY-MM-DD)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { }
                //    }
                //},
                //new Tool
                //{
                //    Name = "analytics_metrics_genesys",get currenttime
                //    Description = "Consulta métricas de analytics do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["interval"] = new { type = "string", description = "Intervalo das métricas (PT15M, PT30M, PT1H, P1D)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { }
                //    }
                //},
                //new Tool
                //{
                //    Name = "analytics_data_genesys",
                //    Description = "Consulta dados de um relatório específico de analytics do Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["report_id"] = new { type = "string", description = "ID do relatório" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { "report_id" }
                //    }
                //},
                new Tool
                {
                    Name = "presence_definitions_genesys",
                    Description = "Lista todas as definições de presença disponíveis no Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                        },
                        Required = new string[] { }
                    }
                },
                //new Tool
                //{
                //    Name = "user_presence_genesys",
                //    Description = "Consulta o status de presença atual de um usuário específico no Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["user_id"] = new { type = "string", description = "ID do usuário" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { "user_id" }
                //    }
                //},
                //new Tool
                //{
                //    Name = "presence_history_genesys",
                //    Description = "Consulta o histórico de presença de um usuário no Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["user_id"] = new { type = "string", description = "ID do usuário" },
                //            ["start_date"] = new { type = "string", description = "Data de início (ISO 8601)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (ISO 8601)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { "user_id" }
                //    }
                //},
                new Tool
                {
                    Name = "gamification_profiles_genesys",
                    Description = "Lista os perfis de gamificação disponíveis no Genesys Cloud",
                    InputSchema = new ToolInputSchema
                    {
                        Type = "object",
                        Properties = new Dictionary<string, object>
                        {
                            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                        },
                        Required = new string[] { }
                    }
                }
                //new Tool
                //{
                //    Name = "gamification_metrics_genesys",
                //    Description = "Consulta as métricas de gamificação de um usuário no Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["user_id"] = new { type = "string", description = "ID do usuário" },
                //            ["profile_id"] = new { type = "string", description = "ID do perfil de gamificação" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { "user_id" }
                //    }
                //},
                //new Tool
                //{
                //    Name = "gamification_leaderboard_genesys",
                //    Description = "Consulta o leaderboard de gamificação no Genesys Cloud",
                //    InputSchema = new ToolInputSchema
                //    {
                //        Type = "object",
                //        Properties = new Dictionary<string, object>
                //        {
                //            ["profile_id"] = new { type = "string", description = "ID do perfil de gamificação" },
                //            ["start_date"] = new { type = "string", description = "Data de início (ISO 8601)" },
                //            ["end_date"] = new { type = "string", description = "Data de fim (ISO 8601)" },
                //            ["export_format"] = new { type = "string", description = "Formato de exportação (json, csv)", @default = "json" }
                //        },
                //        Required = new string[] { "profile_id" }
                //    }
                //}

            };
        }

        private List<Resource> InitializeResources()
        {
            return new List<Resource>
            {
                new Resource
                {
                    Uri = "file://server-info.txt",
                    Name = "Informações do Servidor",
                    Description = "Informações sobre o servidor MCP",
                    MimeType = "text/plain"
                },
                new Resource
                {
                    Uri = "file://capabilities.json",
                    Name = "Capacidades do Servidor",
                    Description = "Lista das capacidades suportadas pelo servidor",
                    MimeType = "application/json"
                }
            };
        }

        private List<Prompt> InitializePrompts()
        {
            return new List<Prompt>
            {
                new Prompt
                {
                    Name = "greeting",
                    Description = "Gera uma saudação personalizada",
                    Arguments = new[]
                    {
                        new PromptArgument
                        {
                            Name = "name",
                            Description = "Nome da pessoa para saudar",
                            Required = true
                        }
                    }
                },
                new Prompt
                {
                    Name = "help",
                    Description = "Fornece informações de ajuda sobre o servidor MCP",
                    Arguments = Array.Empty<PromptArgument>()
                }
            };
        }

        private async Task<string> ExecuteTool(string toolName, Dictionary<string, object>? arguments)
        {
            await Task.Delay(10); // Simula processamento assíncrono

            return toolName switch
            {
                "echo" => arguments?.ContainsKey("text") == true ? arguments["text"].ToString() ?? "" : "Nenhum texto fornecido",
                "current_time" => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss UTC"),
                "get_time_api" => await GetTimeFromApi(arguments?.ContainsKey("format") == true ? arguments["format"].ToString() : "simple"),
                "calculate" => CalculateExpression(arguments?.ContainsKey("expression") == true ? arguments["expression"].ToString() : ""),
                "process_question" => await ProcessNaturalLanguageQuestion(arguments?.ContainsKey("question") == true ? arguments["question"].ToString() ?? "" : ""),
                "filas_geneys" => await GetGenesysQueues(arguments),
                "skills_geneys" => await GetGenesysSkills(arguments),
                "user_geneys" => await GetGenesysUsers(arguments),
                "agents_geneys" => await GetGenesysAgents(arguments),
                "routing_geneys" => await GetGenesysRouting(arguments),
                "campaigns_geneys" => await GetGenesysCampaigns(arguments),
                "analytics_geneys" => await GetGenesysAnalytics(arguments),
                "integrations_geneys" => await GetGenesysIntegrations(arguments),
                "inventory_users_genesys" => await GetGenesysUsers(arguments),
                "inventory_queues_genesys" => await GetGenesysQueues(arguments),
                "inventory_skills_genesys" => await GetGenesysSkills(arguments),
                "inventory_routing_genesys" => await GetGenesysRouting(arguments),
                "inventory_campaigns_genesys" => await GetGenesysCampaigns(arguments),
                "inventory_analytics_genesys" => await GetGenesysAnalytics(arguments),
                "inventory_integrations_genesys" => await GetGenesysIntegrations(arguments),
                "config_divisions_genesys" => await GetConfigDivisions(arguments),
                "config_locations_genesys" => await GetConfigLocations(arguments),
                "config_groups_genesys" => await GetConfigGroups(arguments),
                "config_roles_genesys" => await GetConfigRoles(arguments),
                "config_wrapupcodes_genesys" => await GetConfigWrapupCodes(arguments),
                "config_organization_genesys" => await GetConfigOrganization(arguments),
                "config_scripts_genesys" => await GetConfigScripts(arguments),
                "config_export_complete_genesys" => await GetConfigExportComplete(arguments),
                // Ferramentas do Architect
                "architect_prompts_genesys" => await GetArchitectPrompts(arguments),
                "architect_flows_genesys" => await GetArchitectFlows(arguments),
                //"architect_dependencies_genesys" => await GetArchitectDependencies(arguments),
                //"architect_systemprompts_genesys" => await GetArchitectSystemPrompts(arguments),
                // Ferramentas de Workforce Management
                "workforce_management_units_genesys" => await GetWorkforceManagementUnits(arguments),
                //"workforce_schedules_genesys" => await GetWorkforceSchedules(arguments),
                //"workforce_adherence_genesys" => await GetWorkforceAdherence(arguments),
                //"workforce_forecasts_genesys" => await GetWorkforceForecasts(arguments),
                //"workforce_timeoff_genesys" => await GetWorkforceTimeOff(arguments),
                //"quality_evaluations_genesys" => await GetQualityEvaluations(arguments),
                "quality_forms_genesys" => await GetQualityForms(arguments),
                //"quality_calibrations_genesys" => await GetQualityCalibrations(arguments),
                //"conversations_genesys" => await GetConversations(arguments),
                //"conversation_details_genesys" => await GetConversationDetails(arguments),
                //"conversation_metrics_genesys" => await GetConversationMetrics(arguments),
                //"recordings_genesys" => await GetRecordings(arguments),
                //"recording_metadata_genesys" => await GetRecordingMetadata(arguments),
                //"recording_transcription_genesys" => await GetRecordingTranscription(arguments),
                "outbound_campaigns_genesys" => await GetOutboundCampaigns(arguments),
                "contact_lists_genesys" => await GetContactLists(arguments),
                "outbound_sequences_genesys" => await GetOutboundSequences(arguments),
                //"analytics_reports_genesys" => await GetAnalyticsReports(arguments),
                //"analytics_metrics_genesys" => await GetAnalyticsMetrics(arguments),
                //"analytics_data_genesys" => await GetAnalyticsData(arguments),
                "presence_definitions_genesys" => await GetPresenceDefinitions(arguments),
                //"user_presence_genesys" => await GetUserPresence(arguments),
                //"presence_history_genesys" => await GetPresenceHistory(arguments),
                "gamification_profiles_genesys" => await GetGamificationProfiles(arguments),
                //"gamification_metrics_genesys" => await GetGamificationMetrics(arguments),
                //"gamification_leaderboard_genesys" => await GetGamificationLeaderboard(arguments),
                _ => throw new Exception($"Tool '{toolName}' não implementado")
            };
        }

        private async Task<string> GetTimeFromApi(string? format)
        {
            try
            {
                using var httpClient = new HttpClient();
                var apiUrl = format == "detailed" ? "http://localhost:7071/api/time" : "http://localhost:7071/api/time/formatted";
                var response = await httpClient.GetStringAsync(apiUrl);
                return $"Informações de tempo da API: {response}";
            }
            catch
            {
                // Fallback para horário local se a API não estiver disponível
                var now = DateTime.Now;
                var fallbackMessage = format == "detailed"
                    ? $"{{\"currentTime\": \"{now:yyyy-MM-dd HH:mm:ss}\", \"message\": \"API indisponível, usando horário local\"}}"
                    : $"{{\"message\": \"Agora são {now:HH:mm:ss} do dia {now:dd/MM/yyyy} ({now:dddd})\", \"note\": \"Horário local (API indisponível)\"}}";

                return $"Horário (fallback): {fallbackMessage}";
            }
        }

        private string CalculateExpression(string? expression)
        {
            if (string.IsNullOrEmpty(expression))
                return "Expressão vazia";

            try
            {
                // Implementação simples de calculadora (apenas para demonstração)
                // Em produção, use uma biblioteca de parsing de expressões mais robusta
                var result = EvaluateSimpleExpression(expression);
                return result.ToString();
            }
            catch (Exception ex)
            {
                return $"Erro no cálculo: {ex.Message}";
            }
        }

        private async Task<string> ProcessNaturalLanguageQuestion(string question)
        {
            _logger?.LogInformation("ProcessNaturalLanguageQuestion chamada com: '{Question}'", question);

            if (string.IsNullOrEmpty(question))
            {
                _logger?.LogInformation("Pergunta vazia ou nula");
                return "Por favor, faça uma pergunta.";
            }

            var lowerQuestion = question.ToLower().Trim();
            _logger?.LogInformation("Pergunta processada: '{LowerQuestion}'", lowerQuestion);

            // Detecta perguntas sobre tempo
            if (IsTimeQuestion(lowerQuestion))
            {
                _logger?.LogInformation("Detectada pergunta sobre tempo");
                return await GetTimeFromApi("simple");
            }

            // Detecta perguntas de cálculo
            if (IsCalculationQuestion(lowerQuestion))
            {
                _logger?.LogInformation("Detectada pergunta de cálculo");
                var expression = ExtractCalculationFromQuestion(lowerQuestion);
                if (!string.IsNullOrEmpty(expression))
                {
                    return $"Resultado: {CalculateExpression(expression)}";
                }
            }

            // Detecta perguntas de eco/repetição
            if (IsEchoQuestion(lowerQuestion))
            {
                _logger?.LogInformation("Detectada pergunta de eco");
                var textToEcho = ExtractTextToEcho(lowerQuestion);
                return !string.IsNullOrEmpty(textToEcho) ? textToEcho : "Não consegui identificar o que repetir.";
            }

            // Detecta perguntas sobre Genesys
            if (IsGenesysQuestion(lowerQuestion))
            {
                _logger?.LogInformation("Detectada pergunta sobre Genesys");
                return GetGenesysInformation();
            }

            // Detecta perguntas sobre Chuck Norris
            if (IsChuckNorrisQuestion(lowerQuestion))
            {
                _logger?.LogInformation("Detectada pergunta sobre Chuck Norris");
                return await GetChuckNorrisJoke();
            }

            _logger?.LogInformation("Nenhuma condição atendida, retornando mensagem padrão para: '{Question}'", question);
            return $"Desculpe, não consegui entender a pergunta: '{question}'. Tente perguntas como 'que horas são?', 'quanto é 2+2?', 'repita: olá', 'me dê informações do Genesys' ou 'chuck norris é'";
        }

        private bool IsTimeQuestion(string question)
        {
            var timeKeywords = new[] { "que horas", "hora", "horário", "tempo", "agora", "current time", "what time" };
            return timeKeywords.Any(keyword => question.Contains(keyword));
        }

        private bool IsCalculationQuestion(string question)
        {
            var calcKeywords = new[] { "quanto é", "calcule", "soma", "subtração", "multiplicação", "divisão", "+", "-", "*", "/", "=", "calculate", "what is" };
            return calcKeywords.Any(keyword => question.Contains(keyword));
        }

        private bool IsEchoQuestion(string question)
        {
            var echoKeywords = new[] { "repita", "diga", "fale", "echo", "repeat", "say" };
            return echoKeywords.Any(keyword => question.Contains(keyword));
        }

        private bool IsGenesysQuestion(string question)
        {
            var genesysKeywords = new[] { "genesys", "genesys cloud", "informações do genesys", "me dê informações do genesys", "sobre genesys", "o que é genesys" };
            return genesysKeywords.Any(keyword => question.Contains(keyword));
        }

        private bool IsChuckNorrisQuestion(string question)
        {
            var chuckKeywords = new[] { "chuck norris é", "chuck norris", "sobre chuck norris", "fato chuck norris", "piada chuck norris" };
            return chuckKeywords.Any(keyword => question.Contains(keyword));
        }

        private string GetGenesysInformation()
        {
            return @"**Genesys Cloud - Plataforma de Experiência do Cliente**

            O Genesys Cloud é uma plataforma completa de experiência do cliente baseada na nuvem que oferece:

            🔹 **Contact Center as a Service (CCaaS)**: Solução omnichannel para atendimento ao cliente
            🔹 **Roteamento Inteligente**: Direcionamento automático de interações para os agentes mais qualificados
            🔹 **Analytics Avançado**: Insights em tempo real sobre performance e experiência do cliente
            🔹 **Integração APIs**: Conectividade com sistemas CRM, ERP e outras aplicações empresariais
            🔹 **Workforce Management**: Ferramentas para planejamento e otimização de equipes
            🔹 **Canais Múltiplos**: Suporte para voz, chat, email, SMS, redes sociais e WhatsApp
            🔹 **IA e Automação**: Chatbots, análise de sentimentos e automação de processos
            🔹 **IA e Automação**: LEMBRANDO, FOI MOCKADO PARA IDENTIFICAR A CHAMADA DO AZURE
            🔹 **Escalabilidade**: Infraestrutura elástica que se adapta às necessidades do negócio

            **Benefícios Principais:**
            ✅ Redução de custos operacionais
            ✅ Melhoria na satisfação do cliente
            ✅ Aumento da produtividade dos agentes
            ✅ Implementação rápida e flexível
            ✅ Segurança e compliance empresarial

            O Genesys Cloud é utilizado por milhares de empresas globalmente para transformar a experiência do cliente e otimizar operações de contact center.";
        }

        private async Task<string> GetChuckNorrisJoke()
        {
            try
            {
                using var httpClient = new HttpClient();
                var response = await httpClient.GetStringAsync("https://api.chucknorris.io/jokes/random");

                // Parse do JSON para extrair a piada
                var jsonDoc = System.Text.Json.JsonDocument.Parse(response);
                var joke = jsonDoc.RootElement.GetProperty("value").GetString();

                return $"🥋 **Chuck Norris Fact:** {joke}";
            }
            catch (Exception ex)
            {
                return $"Erro ao buscar fato do Chuck Norris: {ex.Message}. Mas aqui vai um fato: Chuck Norris não precisa de APIs, as APIs precisam dele!";
            }
        }

        private string ExtractCalculationFromQuestion(string question)
        {
            // Procura por padrões matemáticos na pergunta
            var patterns = new[]
            {
                @"(\d+(?:\.\d+)?)\s*\+\s*(\d+(?:\.\d+)?)", // 2 + 3
                @"(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)", // 5 - 2
                @"(\d+(?:\.\d+)?)\s*\*\s*(\d+(?:\.\d+)?)", // 4 * 6
                @"(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)"  // 8 / 2
            };

            foreach (var pattern in patterns)
            {
                var match = System.Text.RegularExpressions.Regex.Match(question, pattern);
                if (match.Success)
                {
                    return match.Value;
                }
            }

            // Procura por "quanto é X" onde X pode ser uma expressão
            var quantoMatch = System.Text.RegularExpressions.Regex.Match(question, @"quanto é (.+?)(?:\?|$)");
            if (quantoMatch.Success)
            {
                return quantoMatch.Groups[1].Value.Trim();
            }

            return "";
        }

        private string ExtractTextToEcho(string question)
        {
            // Procura por padrões como "repita: texto" ou "diga texto"
            var patterns = new[]
            {
                @"repita:?\s*(.+)",
                @"diga\s+(.+)",
                @"fale\s+(.+)",
                @"echo:?\s*(.+)",
                @"repeat:?\s*(.+)",
                @"say\s+(.+)"
            };

            foreach (var pattern in patterns)
            {
                var match = System.Text.RegularExpressions.Regex.Match(question, pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                if (match.Success)
                {
                    return match.Groups[1].Value.Trim();
                }
            }

            return "";
        }

        private double EvaluateSimpleExpression(string expression)
        {
            // Implementação muito básica - apenas para demonstração
            expression = expression.Replace(" ", "");

            if (expression.Contains("+"))
            {
                var parts = expression.Split('+');
                return double.Parse(parts[0]) + double.Parse(parts[1]);
            }
            if (expression.Contains("-"))
            {
                var parts = expression.Split('-');
                return double.Parse(parts[0]) - double.Parse(parts[1]);
            }
            if (expression.Contains("*"))
            {
                var parts = expression.Split('*');
                return double.Parse(parts[0]) * double.Parse(parts[1]);
            }
            if (expression.Contains("/"))
            {
                var parts = expression.Split('/');
                return double.Parse(parts[0]) / double.Parse(parts[1]);
            }

            return double.Parse(expression);
        }

        private async Task<string> GetResourceContent(string uri)
        {
            await Task.Delay(10); // Simula acesso assíncrono ao recurso

            return uri switch
            {
                "file://server-info.txt" => "MCP Server Azure Functions v1.0.0\nServidor de protocolo MCP implementado em Azure Functions\nSuporta tools, resources e prompts",
                "file://capabilities.json" => JsonConvert.SerializeObject(new
                {
                    tools = new[] { "echo", "current_time", "calculate" },
                    resources = new[] { "server-info.txt", "capabilities.json" },
                    prompts = new[] { "greeting", "help" }
                }, Newtonsoft.Json.Formatting.Indented),
                _ => throw new Exception($"Resource '{uri}' não encontrado")
            };
        }

        private string GeneratePromptText(string promptName, Dictionary<string, string>? arguments)
        {
            return promptName switch
            {
                "greeting" => $"Olá, {arguments?.GetValueOrDefault("name", "usuário")}! Bem-vindo ao MCP Server Azure Functions.",
                "help" => "Este é um servidor MCP implementado em Azure Functions. Você pode usar os seguintes comandos:\n" +
                         "- tools/list: Lista todas as ferramentas disponíveis\n" +
                         "- tools/call: Executa uma ferramenta específica\n" +
                         "- resources/list: Lista todos os recursos disponíveis\n" +
                         "- resources/read: Lê o conteúdo de um recurso\n" +
                         "- prompts/list: Lista todos os prompts disponíveis\n" +
                         "- prompts/get: Obtém um prompt específico",
                _ => throw new Exception($"Prompt '{promptName}' não encontrado")
            };
        }

        // Métodos para integração com Genesys Cloud API
        private async Task<string> GetGenesysQueues(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var queueId = arguments?.ContainsKey("queue_id") == true ? arguments["queue_id"].ToString() : null;
                var includeStats = arguments?.ContainsKey("include_stats") == true && bool.Parse(arguments["include_stats"].ToString() ?? "false");

                //if (!string.IsNullOrEmpty(queueId))
                //{
                //    // Buscar fila específica por ID
                //    var queue = await _genesysClient.GetQueueByIdAsync(queueId);
                //    if (queue == null)
                //    {
                //        return $"❌ **Fila não encontrada**: ID {queueId}";
                //    }

                //    var queueInfo = $@"📋 **Fila do Genesys Cloud - ID: {queue.Id}**

                //    🔹 **Nome**: {queue.Name ?? "N/A"}
                //    🔹 **Descrição**: {queue.Description ?? "N/A"}
                //    🔹 **Status**: {(queue.State == "active" ? "Ativa" : "Inativa")}
                //    🔹 **Divisão**: {queue.Division?.Name ?? "N/A"}
                //    🔹 **Versão**: {queue.Version}";

                //    if (queue.MediaSettings != null && queue.MediaSettings.Any())
                //    {
                //        var mediaTypes = string.Join(", ", queue.MediaSettings.Keys);
                //        queueInfo += $"\n🔹 **Mídia Suportada**: {mediaTypes}";
                //    }

                //    if (includeStats)
                //    {
                //        try
                //        {
                //            // Tentar obter estatísticas da fila
                //            var stats = await _genesysClient.GetQueueStatsAsync(queueId);
                //            if (stats != null)
                //            {
                //                queueInfo += $@"

                //                📊 **Estatísticas Atuais**:
                //                • Dados obtidos: {DateTime.UtcNow:dd/MM/yyyy HH:mm}
                //                • Status: Disponível";
                //            }
                //        }
                //        catch (Exception ex)
                //        {
                //            queueInfo += $"\n\n⚠️ **Erro ao obter estatísticas**: {ex.Message}";
                //        }
                //    }

                //    return queueInfo;
                //}
                //else
                //{
                    // Listar todas as filas
                    var queues = await _genesysClient.GetQueuesAsync();
                    if (string.IsNullOrEmpty(queues))
                    {
                        return "❌ **Nenhuma fila encontrada**";
                    }

                    //var queueList = "📋 **Lista de Filas do Genesys Cloud**\n\n";
                    //var count = 1;

                    //foreach (var queue in queues.Entities.Take(10)) // Limitar a 10 filas
                    //{
                    //    var status = queue.State == "active" ? "🟢 Ativa" : "🔴 Inativa";
                    //    var mediaTypes = queue.MediaSettings?.Keys != null ? string.Join(", ", queue.MediaSettings.Keys) : "N/A";

                    //    queueList += $"{count}. **{queue.Name ?? "N/A"}** (ID: {queue.Id})\n";
                    //    queueList += $"   • Status: {status} | Mídia: {mediaTypes}\n";
                    //    queueList += $"   • Divisão: {queue.Division?.Name ?? "N/A"}\n\n";
                    //    count++;
                    //}

                    //if (queues.Entities.Count() > 10)
                    //{
                    //    queueList += $"... e mais {queues.Entities.Count() - 10} filas\n\n";
                    //}

                    //queueList += $"📊 **Total de filas**: {queues.Total ?? queues.Entities.Count()}";

                    return queues;
               // }
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao buscar filas do Genesys Cloud");
                return $"❌ **Erro ao acessar API do Genesys Cloud**: {ex.Message}";
            }
        }

        private async Task<string> GetGenesysSkills(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var skillId = arguments?.ContainsKey("skill_id") == true ? arguments["skill_id"].ToString() : null;
                var skillName = arguments?.ContainsKey("skill_name") == true ? arguments["skill_name"].ToString() : null;

                //if (!string.IsNullOrEmpty(skillId))
                //{
                //    // Buscar skill específica por ID
                //    var skill = await _genesysClient.GetSkillByIdAsync(skillId);
                //    if (skill == null)
                //    {
                //        return $"❌ **Skill não encontrada**: ID {skillId}";
                //    }

                //    return $@"🎯 **Skill do Genesys Cloud - ID: {skill.Id}**

                //        🔹 **Nome**: {skill.Name ?? "N/A"}
                //        🔹 **Status**: {(skill.State == "active" ? "Ativa" : "Inativa")}
                //        🔹 **Versão**: {skill.Version}
                //        🔹 **Data de criação**: {skill.DateCreated?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}
                //        🔹 **Última modificação**: {skill.DateModified?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}";
                //}
                //if (!string.IsNullOrEmpty(skillName))
                //{
                //    // Buscar skills por nome
                //    var skills = await _genesysClient.GetSkillsAsync(name: skillName);
                //    if (skills?.Entities == null || !skills.Entities.Any())
                //    {
                //        return $"❌ **Nenhuma skill encontrada com nome**: {skillName}";
                //    }

                //    var skillList = $"🔍 **Busca por Skill: '{skillName}'**\n\n✅ **Resultados encontrados**:\n\n";
                //    var count = 1;

                //    foreach (var skill in skills.Entities.Take(5)) // Limitar a 5 skills
                //    {
                //        var status = skill.State == "active" ? "🟢 Ativa" : "🔴 Inativa";
                //        skillList += $"{count}. **{skill.Name ?? "N/A"}** (ID: {skill.Id})\n";
                //        skillList += $"   • Status: {status}\n\n";
                //        count++;
                //    }

                //    return skillList;
                //}
              
                    // Listar todas as skills
                    var skills = await _genesysClient.GetSkillsAsync();
                    if (string.IsNullOrEmpty(skills))
                    {
                        return "❌ **Nenhuma skill encontrada**";
                    }

                    //var skillList = "🎯 **Lista de Skills do Genesys Cloud**\n\n";
                    //var count = 1;

                    //foreach (var skill in skills.Entities.Take(10)) // Limitar a 10 skills
                    //{
                    //    var status = skill.State == "active" ? "🟢 Ativa" : "🔴 Inativa";
                    //    skillList += $"{count}. **{skill.Name ?? "N/A"}** (ID: {skill.Id})\n";
                    //    skillList += $"   • Status: {status}\n";
                    //    skillList += $"   • Criada: {skill.DateCreated?.ToString("dd/MM/yyyy") ?? "N/A"}\n\n";
                    //    count++;
                    //}

                    //if (skills.Entities.Count() > 10)
                    //{
                    //    skillList += $"... e mais {skills.Entities.Count() - 10} skills\n\n";
                    //}

                    //skillList += $"📊 **Total de skills**: {skills.Total ?? skills.Entities.Count()}";

                    return skills;
                
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao buscar skills do Genesys Cloud");
                return $"❌ **Erro ao acessar API do Genesys Cloud**: {ex.Message}";
            }
        }

        private async Task<string> GetGenesysUsers(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var userId = arguments?.ContainsKey("user_id") == true ? arguments["user_id"].ToString() : null;
                var email = arguments?.ContainsKey("email") == true ? arguments["email"].ToString() : null;
                var includePresence = arguments?.ContainsKey("include_presence") == true && bool.Parse(arguments["include_presence"].ToString() ?? "false");

                if (!string.IsNullOrEmpty(userId))
                {
                    //// Buscar usuário específico por ID
                    //var user = await _genesysClient.GetUserByIdAsync(userId);
                    //if (user == null)
                    //{
                    //    return $"❌ **Usuário não encontrado**: ID {userId}";
                    //}

                    //var userInfo = $@"👤 **Usuário do Genesys Cloud - ID: {user.Id}**

                    //🔹 **Nome**: {user.Name ?? "N/A"}
                    //🔹 **Email**: {user.Email ?? "N/A"}
                    //🔹 **Departamento**: {user.Department ?? "N/A"}
                    //🔹 **ID**: {user.Id ?? "N/A"}
                    //🔹 **Status**: {(user.State == "active" ? "Ativo" : "Inativo")}
                    //🔹 **Versão**: {user.Version}";

                    //if (includePresence && !string.IsNullOrEmpty(user.Id))
                    //{
                    //    try
                    //    {
                    //        var presence = await _genesysClient.GetUserPresenceAsync(user.Id);
                    //        if (presence != null)
                    //        {
                    //            userInfo += $@"

                    //            🟢 **Informações de Presença**:
                    //            • Status atual: {presence.Name ?? "N/A"}
                    //            • Última modificação: {presence.ModifiedDate?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}";
                    //        }
                    //    }
                    //    catch (Exception ex)
                    //    {
                    //        userInfo += $"\n\n⚠️ **Erro ao obter presença**: {ex.Message}";
                    //    }
                    //}

                    //return userInfo.ToString();
                }
                else if (!string.IsNullOrEmpty(email))
                {
                    // Buscar usuários por email
                    var users = await _genesysClient.GetUsersAsync(email: email);
                    //if (users?.Entities == null || !users.Entities.Any())
                    //{
                    //    return $"❌ **Nenhum usuário encontrado com email**: {email}";
                    //}

                    //var user = users.Entities.First();
                    //return $@"🔍 **Busca por Email: '{email}'**

                    //✅ **Usuário encontrado**:

                    //👤 **{user.Name ?? "N/A"}** (ID: {user.Id})
                    //🔹 Email: {user.Email ?? "N/A"}
                    //🔹 Departamento: {user.Department ?? "N/A"}
                    //🔹 Status: {(user.State == "active" ? "Ativo" : "Inativo")}";
                }
                else
                {
                    // Listar todos os usuários
                    var users = await _genesysClient.GetUsersAsync(email: null);
                    if (string.IsNullOrEmpty(users))
                    {
                        return "❌ **Nenhum usuário encontrado**";
                    }

                    //var userList = "👥 **Lista de Usuários do Genesys Cloud**\n\n";
                    //var count = 1;

                    //foreach (var user in users.Entities.Take(10)) // Limitar a 10 usuários
                    //{
                    //    var status = user.State == "active" ? "🟢 Ativo" : "🔴 Inativo";
                    //    userList += $"{count}. **{user.Name ?? "N/A"}** (ID: {user.Id})\n";
                    //    userList += $"   • Email: {user.Email ?? "N/A"} | Depto: {user.Department ?? "N/A"}\n";
                    //    userList += $"   • Status: {status}\n\n";
                    //    count++;
                    //}

                    //if (users.Entities.Count() > 10)
                    //{
                    //    userList += $"... e mais {users.Entities.Count() - 10} usuários\n\n";
                    //}

                    //userList += $"📊 **Total de usuários**: {users.Total ?? users.Entities.Count()}";

                    return users;
                }

                return "❌ **Erro**: Parâmetros insuficientes para buscar usuário (forneça user_id ou email)";
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao buscar usuários do Genesys Cloud");
                return $"❌ **Erro ao acessar API do Genesys Cloud**: {ex.Message}";
            }
        }

        private async Task<string> GetGenesysAgents(Dictionary<string, object>? arguments)
        {
            await Task.Delay(100); // Simula chamada à API

            var agentId = arguments?.ContainsKey("agent_id") == true ? arguments["agent_id"].ToString() : null;
            var queueId = arguments?.ContainsKey("queue_id") == true ? arguments["queue_id"].ToString() : null;
            var status = arguments?.ContainsKey("status") == true ? arguments["status"].ToString() : null;

            if (!string.IsNullOrEmpty(agentId))
            {
                return $@"🎧 **Agente do Genesys Cloud - ID: {agentId}**

                    🔹 **Nome**: João Silva Santos
                    🔹 **Email**: joao.silva@empresa.com
                    🔹 **Status atual**: Disponível
                    🔹 **Fila principal**: Suporte Técnico Premium
                    🔹 **Skills**: Suporte Técnico Avançado (9/10), Inglês (8/10)
                    🔹 **Tempo online hoje**: 6h 45m
                    🔹 **Interações hoje**: 23
                    🔹 **Taxa de resolução**: 94.2%
                    🔹 **Avaliação média**: 4.8/5.0

                    📊 **Estatísticas do Dia**:
                    • Chamadas atendidas: 18
                    • Chats atendidos: 5
                    • Tempo médio por interação: 8m 15s
                    • Tempo em pausa: 45m";
            }
            else if (!string.IsNullOrEmpty(queueId))
            {
                return $@"🎧 **Agentes na Fila: {queueId}**

                ✅ **Agentes Disponíveis** (8):
                1. João Silva Santos - Skill: 9/10
                2. Maria Oliveira Costa - Skill: 8/10
                3. Carlos Roberto Lima - Skill: 7/10
                4. Ana Paula Ferreira - Skill: 9/10

                🔴 **Agentes Ocupados** (15):
                5. Pedro Henrique Souza - Em chamada (12m)
                6. Lucia Santos Pereira - Em chat (5m)
                7. Roberto Carlos Silva - Em email (3m)
                [... e mais 12 agentes]

                ⏸️ **Agentes em Pausa** (2):
                8. Fernando Lima Costa - Pausa (8m)
                9. Juliana Rocha Santos - Almoço (25m)";
            }
            else if (!string.IsNullOrEmpty(status))
            {
                var statusEmoji = status.ToLower() switch
                {
                    "available" => "🟢",
                    "busy" => "🔴",
                    "away" => "🟡",
                    _ => "⚪"
                };

                return $@"🎧 **Agentes com Status: {statusEmoji} {status}**

                {GetAgentsByStatus(status)}";
            }
            else
            {
                return @"🎧 **Resumo de Agentes do Genesys Cloud**

                📊 **Status Geral**:
                🟢 **Disponíveis**: 28 agentes
                🔴 **Ocupados**: 45 agentes  
                🟡 **Ausentes**: 8 agentes
                ⚪ **Offline**: 12 agentes

                🏆 **Top Performers Hoje**:
                1. João Silva Santos - 23 interações | 94.2% resolução
                2. Maria Oliveira Costa - 21 interações | 92.8% resolução
                3. Ana Paula Ferreira - 19 interações | 91.5% resolução

                ⏱️ **Métricas Gerais**:
                • Tempo médio de atendimento: 7m 42s
                • Taxa de resolução geral: 89.3%
                • Satisfação do cliente: 4.6/5.0

                💡 **Nota**: Esta é uma simulação da API do Genesys Cloud.";
            }
        }

        private async Task<string> GetGenesysRouting(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var routingType = arguments?.ContainsKey("routing_type") == true ? arguments["routing_type"].ToString() : null;
                var targetId = arguments?.ContainsKey("target_id") == true ? arguments["target_id"].ToString() : null;
                var includeRules = arguments?.ContainsKey("include_rules") == true && bool.Parse(arguments["include_rules"].ToString() ?? "false");

                //if (!string.IsNullOrEmpty(routingType))
                //{
                //    var routingInfo = routingType.ToLower() switch
                //    {
                //        "queue" => await GetQueueRoutingInfoAsync(targetId, includeRules),
                //        "skill" => await GetSkillRoutingInfoAsync(targetId, includeRules),
                //        "agent" => await GetAgentRoutingInfoAsync(targetId, includeRules),
                //        _ => "❌ Tipo de roteamento inválido. Use: queue, skill ou agent"
                //    };

                //    return routingInfo;
                //}
                //else
                //{
                    // Buscar estatísticas gerais de roteamento
                    var routingStats = await _genesysClient.GetRoutingStatsAsync();

                return routingStats;

                    //if (routingStats != null)
                    //{
                    //    return $@"🔀 **Sistema de Roteamento do Genesys Cloud**

                    //    📋 **Tipos de Roteamento Disponíveis**:

                    //    1. **Queue Routing** 🎯
                    //       • Roteamento baseado em filas
                    //       • Priorização por tempo de espera
                    //       • Distribuição por skills

                    //    2. **Skill-Based Routing** 🎪
                    //       • Roteamento por competências
                    //       • Matching automático de skills
                    //       • Níveis de proficiência

                    //    3. **Agent Routing** 👤
                    //       • Roteamento direto para agente
                    //       • Preferências de cliente
                    //       • Histórico de interações

                    //    📊 **Estatísticas de Roteamento (Dados Reais)**:
                    //    {System.Text.Json.JsonSerializer.Serialize(routingStats, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })}";
                    //}
                    //else
                    //{
                    //    return @"🔀 **Sistema de Roteamento do Genesys Cloud**

                    //    📋 **Tipos de Roteamento Disponíveis**:

                    //    1. **Queue Routing** 🎯
                    //    2. **Skill-Based Routing** 🎪
                    //    3. **Agent Routing** 👤

                    //    ⚠️ **Nota**: Não foi possível obter estatísticas em tempo real.";
                    //}
               // }
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao buscar informações de roteamento do Genesys Cloud");
                return $"❌ **Erro ao acessar API de Roteamento do Genesys Cloud**: {ex.Message}";
            }

        }

        private async Task<string> GetGenesysCampaigns(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var campaignId = arguments?.ContainsKey("campaign_id") == true ? arguments["campaign_id"].ToString() : null;
                var campaignType = arguments?.ContainsKey("campaign_type") == true ? arguments["campaign_type"].ToString() : null;
                var status = arguments?.ContainsKey("status") == true ? arguments["status"].ToString() : null;
                var includeStats = arguments?.ContainsKey("include_stats") == true && bool.Parse(arguments["include_stats"].ToString() ?? "false");

                //if (!string.IsNullOrEmpty(campaignId))
                //{
                //    // Buscar campanha específica por ID
                //    var campaign = await _genesysClient.GetCampaignByIdAsync(campaignId);
                //    if (campaign == null)
                //    {
                //        return $"❌ **Campanha não encontrada**: ID {campaignId}";
                //    }

                //    var campaignInfo = $@"📢 **Campanha do Genesys Cloud - ID: {campaign.Id}**

                //    🔹 **Nome**: {campaign.Name ?? "N/A"}
                //    🔹 **Modo de Discagem**: {campaign.DialingMode ?? "N/A"}
                //    🔹 **Status**: {campaign.CampaignStatus ?? "N/A"}
                //    🔹 **Data de Criação**: {campaign.DateCreated?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}
                //    🔹 **Última Modificação**: {campaign.DateModified?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}
                //    🔹 **Versão**: {campaign.Version}";

                //    if (includeStats)
                //    {
                //        try
                //        {
                //            var stats = await _genesysClient.GetCampaignStatsAsync(campaignId);
                //            if (stats != null)
                //            {
                //                campaignInfo += $@"

                //                📊 **Estatísticas da Campanha**:
                //                {System.Text.Json.JsonSerializer.Serialize(stats, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })}";
                //            }
                //        }
                //        catch (Exception ex)
                //        {
                //            campaignInfo += $"\n\n⚠️ **Erro ao obter estatísticas**: {ex.Message}";
                //        }
                //    }

                //    return campaignInfo;
                //}
                //else
                //{
                    // Listar todas as campanhas
                    var campaigns = await _genesysClient.GetCampaignsAsync();
                    if (string.IsNullOrEmpty(campaigns))
                    {
                        return "❌ **Nenhuma campanha encontrada**";
                    }

                    //var campaignList = "📢 **Lista de Campanhas do Genesys Cloud**\n\n";
                    //var count = 1;

                    //var filteredCampaigns = campaigns.Entities.AsEnumerable();

                    //if (!string.IsNullOrEmpty(campaignType))
                    //{
                    //    filteredCampaigns = filteredCampaigns.Where(c => c.DialingMode?.ToLower() == campaignType.ToLower());
                    //}

                    //if (!string.IsNullOrEmpty(status))
                    //{
                    //    filteredCampaigns = filteredCampaigns.Where(c => c.CampaignStatus?.ToLower() == status.ToLower());
                    //}

                    //foreach (var campaign in filteredCampaigns)
                    //{
                    //    var statusEmoji = campaign.CampaignStatus?.ToLower() switch
                    //    {
                    //        "on" => "🟢",
                    //        "off" => "🔴",
                    //        "paused" => "🟡",
                    //        _ => "⚪"
                    //    };

                    //    campaignList += $"{count}. **{campaign.Name ?? "N/A"}** (ID: {campaign.Id})\n";
                    //    campaignList += $"   • Modo: {campaign.DialingMode ?? "N/A"} | Status: {statusEmoji} {campaign.CampaignStatus ?? "N/A"}\n\n";
                    //    count++;
                    //}

                    //if (campaigns.Entities.Count() > 10)
                    //{
                    //    campaignList += $"... e mais {campaigns.Entities.Count() - 10} campanhas\n\n";
                    //}

                    //campaignList += $"📊 **Total de campanhas**: {campaigns.Total ?? campaigns.Entities.Count()}";

                    return campaigns;
                //}
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao buscar campanhas do Genesys Cloud");
                return $"❌ **Erro ao acessar API de Campanhas do Genesys Cloud**: {ex.Message}";
            }
        }

        private async Task<string> GetGenesysAnalytics(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var reportType = arguments?.ContainsKey("report_type") == true ? arguments["report_type"].ToString() : null;
                var startDateStr = arguments?.ContainsKey("start_date") == true ? arguments["start_date"].ToString() : null;
                var endDateStr = arguments?.ContainsKey("end_date") == true ? arguments["end_date"].ToString() : null;
                var queueId = arguments?.ContainsKey("queue_id") == true ? arguments["queue_id"].ToString() : null;
                var metrics = arguments?.ContainsKey("metrics") == true ? arguments["metrics"].ToString() : null;

                // Definir datas padrão se não fornecidas
                var endDate = DateTime.UtcNow;
                var startDate = endDate.AddDays(-7); // Últimos 7 dias por padrão

                if (!string.IsNullOrEmpty(startDateStr) && DateTime.TryParse(startDateStr, out var parsedStartDate))
                {
                    startDate = parsedStartDate;
                }

                if (!string.IsNullOrEmpty(endDateStr) && DateTime.TryParse(endDateStr, out var parsedEndDate))
                {
                    endDate = parsedEndDate;
                }

                var analyticsInfo = $@"📊 **Analytics do Genesys Cloud**

                🔹 **Período**: {startDate:dd/MM/yyyy} a {endDate:dd/MM/yyyy}
                🔹 **Tipo de Relatório**: {reportType ?? "Geral"}
                🔹 **Métricas**: {metrics ?? "Todas"}";

                if (!string.IsNullOrEmpty(queueId))
                {
                    analyticsInfo += $"\n🔹 **Fila**: {queueId}";
                }

                try
                {
                    if (reportType?.ToLower() == "conversations")
                    {
                        var conversationDetails = await _genesysClient.GetConversationDetailsAsync(startDate, endDate, queueId);
                        if (conversationDetails != null)
                        {
                            analyticsInfo += $@"

                            📞 **Detalhes de Conversações**:
                            {System.Text.Json.JsonSerializer.Serialize(conversationDetails, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })}";
                        }
                    }
                    else if (reportType?.ToLower() == "queues")
                    {
                        var queueObservations = await _genesysClient.GetQueueObservationsAsync(startDate, endDate);
                        if (queueObservations != null)
                        {
                            analyticsInfo += $@"

                            📋 **Observações de Filas**:
                            {System.Text.Json.JsonSerializer.Serialize(queueObservations, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })}";
                        }
                    }
                    else
                    {
                        // Buscar dados gerais de analytics
                        var analyticsData = await _genesysClient.GetAnalyticsDataAsync(startDate, endDate, metrics);
                        if (analyticsData != null)
                        {
                            analyticsInfo += $@"

                            📈 **Dados de Analytics**:
                            {System.Text.Json.JsonSerializer.Serialize(analyticsData, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })}";
                        }
                    }
                }
                catch (Exception ex)
                {
                    analyticsInfo += $"\n\n⚠️ **Erro ao obter dados de analytics**: {ex.Message}";
                }

                return analyticsInfo;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao buscar dados de analytics do Genesys Cloud");
                return $"❌ **Erro ao acessar API de Analytics do Genesys Cloud**: {ex.Message}";
            }
        }

        private async Task<string> GetGenesysIntegrations(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var integrationId = arguments?.ContainsKey("integration_id") == true ? arguments["integration_id"].ToString() : null;
                var integrationType = arguments?.ContainsKey("integration_type") == true ? arguments["integration_type"].ToString() : null;
                var status = arguments?.ContainsKey("status") == true ? arguments["status"].ToString() : null;
                var includeConfig = arguments?.ContainsKey("include_config") == true && bool.Parse(arguments["include_config"].ToString() ?? "false");

                if (!string.IsNullOrEmpty(integrationId))
                {
                    // Buscar integração específica por ID
                    var integration = await _genesysClient.GetIntegrationByIdAsync(integrationId);
                    if (integration == null)
                    {
                        return $"❌ **Integração não encontrada**: ID {integrationId}";
                    }

                    var integrationInfo = $@"🔗 **Integração do Genesys Cloud - ID: {integration.Id}**

                    🔹 **Nome**: {integration.Name ?? "N/A"}
                    🔹 **Tipo**: {integration.IntegrationType?.Name ?? "N/A"}
                    🔹 **Status**: {integration.ReportedState ?? "N/A"}
                    🔹 **Versão**: {integration.Version?.ToString() ?? "N/A"}
                    🔹 **Data de Criação**: {integration.DateCreated?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}
                    🔹 **Última Modificação**: {integration.DateModified?.ToString("dd/MM/yyyy HH:mm") ?? "N/A"}";

                    if (includeConfig && integration.Config != null)
                    {
                        integrationInfo += $@"

                        ⚙️ **Configuração**:
                        {System.Text.Json.JsonSerializer.Serialize(integration.Config, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })}";
                    }

                    return integrationInfo;
                }
                else
                {
                    // Listar todas as integrações
                    var integrations = await _genesysClient.GetIntegrationsAsync();
                    if (string.IsNullOrEmpty(integrations))
                    {
                        return "❌ **Nenhuma integração encontrada**";
                    }

                    //var integrationList = "🔗 **Lista de Integrações do Genesys Cloud**\n\n";
                    //var count = 1;

                    //var filteredIntegrations = integrations.Entities.AsEnumerable();

                    //if (!string.IsNullOrEmpty(integrationType))
                    //{
                    //    filteredIntegrations = filteredIntegrations.Where(i => i.IntegrationType?.Name?.ToLower() == integrationType.ToLower());
                    //}

                    //if (!string.IsNullOrEmpty(status))
                    //{
                    //    filteredIntegrations = filteredIntegrations.Where(i => i.ReportedState?.ToLower() == status.ToLower());
                    //}

                    //foreach (var integration in filteredIntegrations.Take(10))
                    //{
                    //    var statusEmoji = integration.ReportedState?.ToLower() switch
                    //    {
                    //        "enabled" => "🟢",
                    //        "disabled" => "🔴",
                    //        "error" => "❌",
                    //        _ => "⚪"
                    //    };

                    //    integrationList += $"{count}. **{integration.Name ?? "N/A"}** (ID: {integration.Id})\n";
                    //    integrationList += $"   • Tipo: {integration.IntegrationType?.Name ?? "N/A"} | Status: {statusEmoji} {integration.ReportedState ?? "N/A"}\n\n";
                    //    count++;
                    //}

                    //if (integrations.Entities.Count() > 10)
                    //{
                    //    integrationList += $"... e mais {integrations.Entities.Count() - 10} integrações\n\n";
                    //}

                    //integrationList += $"📊 **Total de integrações**: {integrations.Total ?? integrations.Entities.Count()}";

                    // Adicionar informações sobre tipos de integração disponíveis
                    //try
                    //{
                    //    var integrationTypes = await _genesysClient.GetIntegrationTypesAsync();
                    //    if (integrationTypes?.Entities != null && integrationTypes.Entities.Any())
                    //    {
                    //        integrationList += "\n\n🔧 **Tipos de Integração Disponíveis**:\n";
                    //        foreach (var type in integrationTypes.Entities.Take(5))
                    //        {
                    //            integrationList += $"• {type.Name ?? "N/A"} ({type.Id})\n";
                    //        }
                    //    }
                    //}
                    //catch (Exception ex)
                    //{
                    //    integrationList += $"\n\n⚠️ **Erro ao obter tipos de integração**: {ex.Message}";
                    //}

                    return integrations;
                }
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao buscar integrações do Genesys Cloud");
                return $"❌ **Erro ao acessar API de Integrações do Genesys Cloud**: {ex.Message}";
            }
        }

        private string GetAgentsByStatus(string status)
        {
            return status.ToLower() switch
            {
                "available" => @"1. João Silva Santos - Suporte Técnico
                2. Maria Oliveira Costa - Vendas Corporativas
                3. Ana Paula Ferreira - Retenção
                4. Carlos Roberto Lima - Financeiro
                [... e mais 24 agentes disponíveis]",
                                "busy" => @"1. Pedro Henrique Souza - Em chamada (12m)
                2. Lucia Santos Pereira - Em chat (5m)
                3. Roberto Carlos Silva - Em email (3m)
                4. Fernando Lima Costa - Em chamada (8m)
                [... e mais 41 agentes ocupados]",
                                "away" => @"1. Juliana Rocha Santos - Almoço (25m)
                2. Ricardo Alves Costa - Pausa (8m)
                3. Patricia Lima Silva - Reunião (15m)
                [... e mais 5 agentes ausentes]",
                                _ => "Status não reconhecido"
            };
        }

        private string GetQueueRoutingInfo(string? targetId, bool includeRules)
        {
            var info = $@"🎯 **Roteamento por Fila**

🔹 **Fila**: {targetId ?? "Todas as filas"}
🔹 **Algoritmo**: Longest Idle Agent
🔹 **Prioridade**: Por tempo de espera
🔹 **Overflow**: Fila secundária após 5min";

            if (includeRules)
            {
                info += @"

📋 **Regras de Roteamento**:
1. Verificar disponibilidade de agentes
2. Aplicar filtro de skills obrigatórias
3. Selecionar agente com maior tempo idle
4. Se nenhum disponível, adicionar à fila
5. Após 5min, escalar para supervisor";
            }

            return info;
        }

        private string GetSkillRoutingInfo(string? targetId, bool includeRules)
        {
            var info = $@"🎪 **Roteamento por Skill**

🔹 **Skill**: {targetId ?? "Todas as skills"}
🔹 **Algoritmo**: Best Available Agent
🔹 **Critério**: Maior nível de proficiência
🔹 **Fallback**: Skill secundária";

            if (includeRules)
            {
                info += @"

📋 **Regras de Roteamento**:
1. Identificar skills requeridas
2. Buscar agentes com nível >= mínimo
3. Priorizar por maior proficiência
4. Considerar carga de trabalho atual
5. Fallback para skills relacionadas";
            }

            return info;
        }

        private string GetAgentRoutingInfo(string? targetId, bool includeRules)
        {
            var info = $@"👤 **Roteamento Direto para Agente**

🔹 **Agente**: {targetId ?? "Agente específico"}
🔹 **Tipo**: Roteamento direto
🔹 **Prioridade**: Alta
🔹 **Fallback**: Fila do agente";

            if (includeRules)
            {
                info += @"

📋 **Regras de Roteamento**:
1. Verificar disponibilidade do agente
2. Se disponível, rotear imediatamente
3. Se ocupado, verificar fila pessoal
4. Aplicar timeout de 30s
5. Fallback para fila principal";
            }

            return info;
        }

        // Métodos de Inventário para Migraçãobb
        private async Task<string> GetInventoryUsers(Dictionary<string, object>? arguments)
        {
            await Task.Delay(200); // Simula chamada à API

            var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
            var includeInactive = arguments?.ContainsKey("include_inactive") == true && bool.Parse(arguments["include_inactive"].ToString() ?? "false");
            var departmentFilter = arguments?.ContainsKey("department_filter") == true ? arguments["department_filter"].ToString() : null;

            var inventoryData = new
            {
                export_timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC"),
                total_users = includeInactive ? 247 : 198,
                active_users = 198,
                inactive_users = 49,
                department_filter = departmentFilter,
                users = new[]
                {
                    new {
                        id = "usr_001",
                        name = "João Silva Santos",
                        email = "joao.silva@empresa.com",
                        department = "Suporte Técnico",
                        roles = new[] { "Agent", "Supervisor" },
                        skills = new[] { "Português", "Técnico Nível 2", "CRM" },
                        status = "active",
                        hire_date = "2022-03-15",
                        last_login = "2024-01-15 14:30:00",
                        phone_extension = "2001",
                        manager = "Maria Oliveira Costa"
                    },
                    new {
                        id = "usr_002",
                        name = "Maria Oliveira Costa",
                        email = "maria.costa@empresa.com",
                        department = "Vendas",
                        roles = new[] { "Supervisor", "Admin" },
                        skills = new[] { "Vendas", "Liderança", "Inglês" },
                        status = "active",
                        hire_date = "2020-01-10",
                        last_login = "2024-01-15 15:45:00",
                        phone_extension = "2002",
                        manager = "Carlos Roberto Lima"
                    }
                }
            };

            return exportFormat?.ToLower() switch
            {
                "csv" => ConvertToCsv(inventoryData),
                "xml" => ConvertToXml(inventoryData),
                _ => System.Text.Json.JsonSerializer.Serialize(inventoryData, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
            };
        }

        private async Task<string> GetInventoryQueues(Dictionary<string, object>? arguments)
        {
            await Task.Delay(200);

            var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
            var includeConfig = arguments?.ContainsKey("include_config") == true && bool.Parse(arguments["include_config"].ToString() ?? "true");
            var includeSla = arguments?.ContainsKey("include_sla") == true && bool.Parse(arguments["include_sla"].ToString() ?? "true");

            var inventoryData = new
            {
                export_timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC"),
                total_queues = 15,
                active_queues = 12,
                inactive_queues = 3,
                queues = new[]
                {
                    new {
                        id = "queue_001",
                        name = "Suporte Técnico",
                        description = "Fila para atendimento de suporte técnico",
                        status = "active",
                        members = new[] { "usr_001", "usr_003", "usr_005" },
                        required_skills = new[] { "Técnico Nível 1", "Português" },
                        sla_config = includeSla ? new {
                            answer_time_target = 30,
                            abandon_rate_target = 5.0,
                            service_level_target = 80.0
                        } : null,
                        routing_config = includeConfig ? new {
                            algorithm = "Longest Idle",
                            overflow_queue = "queue_002",
                            max_wait_time = 300
                        } : null
                    },
                    new {
                        id = "queue_002",
                        name = "Vendas",
                        description = "Fila para atendimento de vendas",
                        status = "active",
                        members = new[] { "usr_002", "usr_004", "usr_006" },
                        required_skills = new[] { "Vendas", "Português" },
                        sla_config = includeSla ? new {
                            answer_time_target = 20,
                            abandon_rate_target = 3.0,
                            service_level_target = 85.0
                        } : null,
                        routing_config = includeConfig ? new {
                            algorithm = "Skills Based",
                            overflow_queue = "",
                            max_wait_time = 180
                        } : null
                    }
                }
            };

            return exportFormat?.ToLower() switch
            {
                "csv" => ConvertToCsv(inventoryData),
                "xml" => ConvertToXml(inventoryData),
                _ => System.Text.Json.JsonSerializer.Serialize(inventoryData, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
            };
        }

        private async Task<string> GetInventorySkills(Dictionary<string, object>? arguments)
        {
            await Task.Delay(150);

            var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
            var includeAssignments = arguments?.ContainsKey("include_assignments") == true && bool.Parse(arguments["include_assignments"].ToString() ?? "true");
            var categoryFilter = arguments?.ContainsKey("category_filter") == true ? arguments["category_filter"].ToString() : null;

            var inventoryData = new
            {
                export_timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC"),
                total_skills = 28,
                category_filter = categoryFilter,
                skills = new[]
                {
                    new {
                        id = "skill_001",
                        name = "Português",
                        category = "language",
                        description = "Fluência em português brasileiro",
                        proficiency_levels = new[] { 1, 2, 3, 4, 5 },
                        assignments = includeAssignments ? new[] {
                            new { user_id = "usr_001", level = 5 },
                            new { user_id = "usr_002", level = 5 },
                            new { user_id = "usr_003", level = 4 }
                        } : null
                    },
                    new {
                        id = "skill_002",
                        name = "Técnico Nível 2",
                        category = "technical",
                        description = "Suporte técnico avançado",
                        proficiency_levels = new[] { 1, 2, 3, 4, 5 },
                        assignments = includeAssignments ? new[] {
                            new { user_id = "usr_001", level = 4 },
                            new { user_id = "usr_005", level = 5 }
                        } : null
                    },
                    new {
                        id = "skill_003",
                        name = "Vendas",
                        category = "soft",
                        description = "Habilidades de vendas e negociação",
                        proficiency_levels = new[] { 1, 2, 3, 4, 5 },
                        assignments = includeAssignments ? new[] {
                            new { user_id = "usr_002", level = 5 },
                            new { user_id = "usr_004", level = 4 },
                            new { user_id = "usr_006", level = 3 }
                        } : null
                    }
                }
            };

            return exportFormat?.ToLower() switch
            {
                "csv" => ConvertToCsv(inventoryData),
                "xml" => ConvertToXml(inventoryData),
                _ => System.Text.Json.JsonSerializer.Serialize(inventoryData, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
            };
        }

        private async Task<string> GetInventoryRouting(Dictionary<string, object>? arguments)
        {
            await Task.Delay(180);

            var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
            var includeFlows = arguments?.ContainsKey("include_flows") == true && bool.Parse(arguments["include_flows"].ToString() ?? "true");
            var includeRules = arguments?.ContainsKey("include_rules") == true && bool.Parse(arguments["include_rules"].ToString() ?? "true");

            var inventoryData = new
            {
                export_timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC"),
                total_routing_configs = 8,
                active_flows = 12,
                routing_rules = 24,
                configurations = new[]
                {
                    new {
                        id = "routing_001",
                        name = "Roteamento Principal",
                        type = "skill_based",
                        priority = 1,
                        status = "active",
                        flows = includeFlows ? new[] {
                            new {
                                flow_id = "flow_001",
                                name = "Atendimento Geral",
                                steps = new[] {
                                    "1. Verificar horário de funcionamento",
                                    "2. Reproduzir mensagem de boas-vindas",
                                    "3. Coletar opção do menu",
                                    "4. Rotear para fila apropriada"
                                }
                            }
                        } : null,
                        rules = includeRules ? new[] {
                            new {
                                rule_id = "rule_001",
                                condition = "skill_match >= 3",
                                action = "route_to_agent",
                                priority = 1
                            },
                            new {
                                rule_id = "rule_002",
                                condition = "wait_time > 300",
                                action = "escalate_to_supervisor",
                                priority = 2
                            }
                        } : null
                    }
                }
            };

            return exportFormat?.ToLower() switch
            {
                "csv" => ConvertToCsv(inventoryData),
                _ => System.Text.Json.JsonSerializer.Serialize(inventoryData, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
            };
        }

        private async Task<string> GetInventoryCampaigns(Dictionary<string, object>? arguments)
        {
            await Task.Delay(160);

            var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
            var includeInactive = arguments?.ContainsKey("include_inactive") == true && bool.Parse(arguments["include_inactive"].ToString() ?? "false");
            var campaignType = arguments?.ContainsKey("campaign_type") == true ? arguments["campaign_type"].ToString() : null;

            var inventoryData = new
            {
                export_timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC"),
                total_campaigns = includeInactive ? 12 : 8,
                active_campaigns = 8,
                inactive_campaigns = 4,
                campaign_type_filter = campaignType,
                campaigns = new[]
                {
                    new {
                        id = "camp_001",
                        name = "Campanha Retenção Q1",
                        type = "preview",
                        status = "active",
                        created_date = "2024-01-01",
                        start_date = "2024-01-15",
                        end_date = "2024-03-31",
                        contact_list_size = 15000,
                        agents_assigned = new[] { "usr_002", "usr_004", "usr_006" },
                        dialing_mode = "preview",
                        max_calls_per_agent = 50,
                        call_analysis_settings = new {
                            answering_machine_detection = true,
                            live_voice_detection = true,
                            call_progress_analysis = true
                        }
                    },
                    new {
                        id = "camp_002",
                        name = "Pesquisa Satisfação",
                        type = "progressive",
                        status = "active",
                        created_date = "2024-01-10",
                        start_date = "2024-01-20",
                        end_date = "2024-02-29",
                        contact_list_size = 8500,
                        agents_assigned = new[] { "usr_007", "usr_008" },
                        dialing_mode = "progressive",
                        max_calls_per_agent = 75,
                        call_analysis_settings = new {
                            answering_machine_detection = false,
                            live_voice_detection = true,
                            call_progress_analysis = true
                        }
                    }
                }
            };

            return exportFormat?.ToLower() switch
            {
                "csv" => ConvertToCsv(inventoryData),
                "xml" => ConvertToXml(inventoryData),
                _ => System.Text.Json.JsonSerializer.Serialize(inventoryData, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
            };
        }

        private async Task<string> GetInventoryAnalytics(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var dateRange = arguments?.ContainsKey("date_range") == true ? arguments["date_range"].ToString() : "30d";
                var metricsType = arguments?.ContainsKey("metrics_type") == true ? arguments["metrics_type"].ToString() : null;

                // Calcular datas baseado no range
                var endDate = DateTime.UtcNow;
                var startDate = dateRange?.ToLower() switch
                {
                    "7d" => endDate.AddDays(-7),
                    "30d" => endDate.AddDays(-30),
                    "90d" => endDate.AddDays(-90),
                    _ => endDate.AddDays(-30)
                };

                // Buscar dados de analytics da API do Genesys Cloud
                var analyticsData = await _genesysClient.GetAnalyticsDataAsync(startDate, endDate, metricsType);

                if (analyticsData == null)
                {
                    return "❌ **Erro**: Não foi possível obter dados de analytics do Genesys Cloud";
                }

                var inventoryData = new
                {
                    export_timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC"),
                    date_range = dateRange,
                    start_date = startDate.ToString("yyyy-MM-dd"),
                    end_date = endDate.ToString("yyyy-MM-dd"),
                    metrics_type_filter = metricsType,
                    source = "Genesys Cloud API",
                    analytics_data = analyticsData
                };

                return exportFormat?.ToLower() switch
                {
                    "csv" => ConvertToCsv(inventoryData),
                    "xml" => ConvertToXml(inventoryData),
                    _ => System.Text.Json.JsonSerializer.Serialize(inventoryData, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
                };
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao buscar dados de analytics do Genesys Cloud");
                return $"❌ **Erro ao acessar API de Analytics do Genesys Cloud**: {ex.Message}";
            }
        }

        private async Task<string> GetInventoryIntegrations(Dictionary<string, object>? arguments)
        {
            await Task.Delay(140);

            var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
            var integrationType = arguments?.ContainsKey("integration_type") == true ? arguments["integration_type"].ToString() : null;
            var includeConfig = arguments?.ContainsKey("include_config") == true && bool.Parse(arguments["include_config"].ToString() ?? "true");

            var inventoryData = new
            {
                export_timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC"),
                total_integrations = 9,
                active_integrations = 7,
                integration_type_filter = integrationType,
                integrations = new object[]
                {
                    new {
                        id = "int_001",
                        name = "Salesforce CRM",
                        type = "crm",
                        status = "active",
                        version = "v2.1",
                        last_sync = "2024-01-15 16:30:00",
                        configuration = includeConfig ? new {
                            endpoint = "https://api.salesforce.com/v1",
                            authentication = "OAuth 2.0",
                            sync_frequency = "real-time",
                            data_mapping = new {
                                customer_id = "Contact.Id",
                                customer_name = "Contact.Name",
                                phone = "Contact.Phone"
                            }
                        } : null
                    },
                    new {
                        id = "int_002",
                        name = "WhatsApp Business",
                        type = "chat",
                        status = "active",
                        version = "v1.3",
                        last_sync = "2024-01-15 16:45:00",
                        configuration = includeConfig ? new {
                            webhook_url = "https://webhook.genesys.com/whatsapp",
                            phone_number = "+5511999999999",
                            business_account_id = "123456789",
                            message_templates = 15
                        } : null
                    },
                    new {
                        id = "int_003",
                        name = "Avaya PBX",
                        type = "telephony",
                        status = "active",
                        version = "v3.0",
                        last_sync = "2024-01-15 16:20:00",
                        configuration = includeConfig ? new {
                            pbx_ip = "192.168.1.100",
                            protocol = "SIP",
                            trunk_groups = 4,
                            extensions_range = "2000-2999"
                        } : null
                    }
                }
            };

            return exportFormat?.ToLower() switch
            {
                "csv" => ConvertToCsv(inventoryData),
                "xml" => ConvertToXml(inventoryData),
                _ => System.Text.Json.JsonSerializer.Serialize(inventoryData, new System.Text.Json.JsonSerializerOptions { WriteIndented = true })
            };
        }

        // Métodos auxiliares para conversão de formato
        private string ConvertToCsv(object data)
        {
            // Implementação simplificada para demonstração
            return $"CSV Export Generated at {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss UTC}\n" +
                   "Note: This is a simplified CSV representation.\n" +
                   "In production, implement proper CSV serialization.\n" +
                   $"Data: {System.Text.Json.JsonSerializer.Serialize(data)}";
        }

        private string ConvertToXml(object data)
        {
            // Implementação simplificada para demonstração
            return $"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                   $"<export timestamp=\"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss UTC}\">\n" +
                   "  <note>This is a simplified XML representation.</note>\n" +
                   "  <note>In production, implement proper XML serialization.</note>\n" +
                   $"  <data>{System.Text.Json.JsonSerializer.Serialize(data)}</data>\n" +
                   "</export>";
        }


        // Métodos para APIs de Configuração Organizacional
        private async Task<string> GetConfigDivisions(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                    return "❌ **Erro**: Cliente Genesys não configurado";

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeObjectCounts = arguments?.ContainsKey("include_object_counts") == true && Convert.ToBoolean(arguments["include_object_counts"]);

                var divisions = await _genesysClient.GetDivisionsAsync();

                //var result = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    total_divisions = divisions.Total,
                //    divisions = divisions.Entities.Select(d => new
                //    {
                //        id = d.Id,
                //        name = d.Name,
                //        description = d.Description,
                //        home_division = d.HomeDivision
                //        //object_counts = includeObjectCounts ? d.ObjectCounts : null
                //    })
                //};

                return divisions;
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao exportar divisões**: {ex.Message}";
            }
        }

        private async Task<string> GetConfigLocations(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                    return "❌ **Erro**: Cliente Genesys não configurado";

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeEmergencyInfo = arguments?.ContainsKey("include_emergency_info") == true && Convert.ToBoolean(arguments["include_emergency_info"]);

                var locations = await _genesysClient.GetLocationsAsync();

                var result = new
                {
                    timestamp = DateTime.UtcNow,
                    total_locations = locations.Total,
                    locations = locations.Entities.Select(l => new
                    {
                        id = l.Id,
                        name = l.Name,
                        description = l.notes,
                        emergency_number = includeEmergencyInfo ? l.emergencyNumber : null,
                        address = l.Address,
                        state = l.State,
                        version = l.version
                    })
                };

                return FormatExportData(result, exportFormat, "locations");
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao exportar localizações**: {ex.Message}";
            }
        }

        private async Task<string> GetConfigGroups(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                    return "❌ **Erro**: Cliente Genesys não configurado";

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeMembers = arguments?.ContainsKey("include_members") == true && Convert.ToBoolean(arguments["include_members"]);

                var groups = await _genesysClient.GetGroupsAsync();

                //var result = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    total_groups = groups.Total,
                //    groups = groups.Entities.Select(g => new
                //    {
                //        id = g.Id,
                //        name = g.Name,
                //        description = g.Description,
                //        type = g.Type,
                //        images = g.Images,
                //        addresses = g.Addresses,
                //        phone_numbers = g.PhoneNumbers,
                //        member_count = includeMembers ? g.MemberCount : null,
                //        state = g.State,
                //        version = g.Version
                //    })
                //};

                return groups;
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao exportar grupos**: {ex.Message}";
            }
        }

        private async Task<string> GetConfigRoles(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                    return "❌ **Erro**: Cliente Genesys não configurado";

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includePermissions = arguments?.ContainsKey("include_permissions") == true && Convert.ToBoolean(arguments["include_permissions"]);

                var roles = await _genesysClient.GetRolesAsync();

                //var result = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    total_roles = roles.total,
                //    roles = roles.Entities.Select(r => new
                //    {
                //        id = r.Id,
                //        name = r.Name,
                //        description = r.Description,
                //        default_role_id = r.defaultRoleId,
                //        permissions = includePermissions ? r.permissions : null,
                //        permission_policies = includePermissions ? r.permissionPolicies : null
                //    })
                //};

                return roles;
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao exportar roles**: {ex.Message}";
            }
        }

        private async Task<string> GetConfigWrapupCodes(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                    return "❌ **Erro**: Cliente Genesys não configurado";

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeDivisionInfo = arguments?.ContainsKey("include_division_info") == true && Convert.ToBoolean(arguments["include_division_info"]);

                var wrapupCodes = await _genesysClient.GetWrapupCodesAsync();

                //var result = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    total_wrapup_codes = wrapupCodes.total,
                //    wrapup_codes = wrapupCodes.Entities.Select(w => new
                //    {
                //        id = w.id,
                //        name = w.name,
                //        division = includeDivisionInfo ? w.division : null,
                //        date_created = w.dateCreated,
                //        date_modified = w.dateModified,
                //        modified_by = w.modifiedBy,
                //        created_by = w.createdBy
                //    })
                //};

                return wrapupCodes;
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao exportar wrap-up codes**: {ex.Message}";
            }
        }

        private async Task<string> GetConfigOrganization(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                    return "❌ **Erro**: Cliente Genesys não configurado";

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeFeatures = arguments?.ContainsKey("include_features") == true && Convert.ToBoolean(arguments["include_features"]);

                var organization = await _genesysClient.GetOrganizationAsync();

                //var result = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    organization = new
                //    {
                //        id = organization.id,
                //        name = organization.name,
                //        default_language = organization.defaultLanguage,
                //        default_country_code = organization.defaultCountryCode,
                //        third_party_org_name = organization.thirdPartyOrgName,
                //        third_party_uri = organization.thirdPartyOrgName,
                //        domain = organization.domain,
                //        version = organization.version,
                //        state = organization.state,
                //        default_site_id = organization.defaultSiteId,
                //        support_uri = organization.selfUri,
                //        voicemail_enabled = organization.voicemailEnabled,
                //        product_platform = organization.productPlatform,
                //        self_uri = organization.selfUri,
                //        features = includeFeatures ? organization.features : null
                //    }
                //};

                return organization;
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao exportar organização**: {ex.Message}";
            }
        }

        private async Task<string> GetConfigScripts(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                    return "❌ **Erro**: Cliente Genesys não configurado";

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeVersions = arguments?.ContainsKey("include_versions") == true && Convert.ToBoolean(arguments["include_versions"]);

                var scripts = await _genesysClient.GetScriptsAsync();

                //var result = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    total_scripts = scripts.Total,
                //    scripts = scripts.Entities.Select(s => new
                //    {
                //        id = s.Id,
                //        name = s.Name,
                //        division = s.Division,
                //        version_id = s.VersionId,
                //        created_by = s.CreatedBy,
                //        created_date = s.CreatedDate,
                //        modified_by = s.ModifiedBy,
                //        modified_date = s.ModifiedDate,
                //        published_date = includeVersions ? s.PublishedDate : null,
                //        published_by = includeVersions ? s.PublishedBy : null,
                //        self_uri = s.SelfUri
                //    })
                //};

                return scripts;
            }
            catch (Exception ex)
            {
                return $"❌ **Erro ao exportar scripts**: {ex.Message}";
            }
        }

        // Métodos das ferramentas do GetArchitectDependenciesAsync
        private async Task<string> GetArchitectPrompts(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeResources = arguments?.ContainsKey("include_resources") == true && Convert.ToBoolean(arguments["include_resources"]);
                var languageFilter = arguments?.ContainsKey("language_filter") == true ? arguments["language_filter"].ToString() : null;

                var prompts = await _genesysClient.GetArchitectPromptsAsync();
                if (string.IsNullOrEmpty(prompts))
                {
                    return "❌ **Nenhum prompt encontrado no Architect**";
                }

                //var filteredPrompts = prompts.Entities.AsEnumerable();
                //if (!string.IsNullOrEmpty(languageFilter))
                //{
                //    filteredPrompts = filteredPrompts.Where(p => p.Resources?.Any(r => r.Language?.Contains(languageFilter, StringComparison.OrdinalIgnoreCase) == true) == true);
                //}

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "architect_prompts",
                //    language_filter = languageFilter,
                //    include_resources = includeResources,
                //    total_prompts = filteredPrompts.Count(),
                //    prompts = filteredPrompts.Select(p => new
                //    {
                //        id = p.Id,
                //        name = p.Name,
                //        description = p.Description,
                //       // created_date = p.CreatedDate,
                //        //modified_date = p.ModifiedDate,
                //        created_by = p.CreatedBy?.Name,
                //        modified_by = p.ModifiedBy?.Name,
                //        resources = includeResources ? p.Resources?.Select(r => new
                //        {
                //            //id = r.Id,
                //            language = r.Language,
                //            media_uri = r.MediaUri,
                //            text = r.Text
                //        }) : null
                //    })
                //};

                return prompts;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao exportar prompts do Architect");
                return $"❌ **Erro ao exportar prompts do Architect**: {ex.Message}";
            }
        }
        private async Task<string> GetArchitectFlows(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var flowType = arguments?.ContainsKey("flow_type") == true ? arguments["flow_type"].ToString() : "all";
                var includeVersions = arguments?.ContainsKey("include_versions") == true && Convert.ToBoolean(arguments["include_versions"]);
                var publishedOnly = arguments?.ContainsKey("published_only") == true && Convert.ToBoolean(arguments["published_only"]);

                var flows = await _genesysClient.GetArchitectFlowsAsync();
                if (string.IsNullOrEmpty(flows))
                {
                    return "❌ **Nenhum fluxo encontrado no Architect**";
                }

                //var filteredFlows = flows.Entities.AsEnumerable();
                //if (flowType != "all")
                //{
                //    filteredFlows = filteredFlows.Where(f => f.Type?.Equals(flowType, StringComparison.OrdinalIgnoreCase) == true);
                //}

                //if (publishedOnly)
                //{
                //    filteredFlows = filteredFlows.Where(f => f.PublishedVersion != null);
                //}

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "architect_flows",
                //    flow_type_filter = flowType,
                //    published_only = publishedOnly,
                //    include_versions = includeVersions,
                //    total_flows = filteredFlows.Count(),
                //    flows = filteredFlows.Select(f => new
                //    {
                //        id = f.Id,
                //        name = f.Name,
                //        description = f.Description,
                //        type = f.Type,
                //        //created_date = f.CreatedDate,
                //        //modified_date = f.ModifiedDate,
                //        created_by = f.CreatedBy?.Name,
                //        modified_by = f.ModifiedBy?.Name,
                //        //published_version = f.PublishedVersion?.Version,
                //        //saved_version = f.SavedVersion?.Version,
                //        //checked_in_version = f.CheckedInVersion?.Version,
                //        versions = includeVersions ? new
                //        {
                //            published = f.PublishedVersion,
                //            //saved = f.SavedVersion,
                //            checked_in = f.CheckedInVersion
                //        } : null
                //    })
                //};

                return flows;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao exportar fluxos do Architect");
                return $"❌ **Erro ao exportar fluxos do Architect**: {ex.Message}";
            }
        }

        //private async Task<string> GetArchitectDependencies(Dictionary<string, object>? arguments)
        //{
        //    try
        //    {
        //        if (_genesysClient == null)
        //        {
        //            return "❌ **Erro**: Cliente Genesys Cloud não configurado";
        //        }

        //        var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
        //        var objectType = arguments?.ContainsKey("object_type") == true ? arguments["object_type"].ToString() : "flow";
        //        var objectId = arguments?.ContainsKey("object_id") == true ? arguments["object_id"].ToString() : null;
        //        var includeReferenced = arguments?.ContainsKey("include_referenced") == true && Convert.ToBoolean(arguments["include_referenced"]);
        //        var includeReferencing = arguments?.ContainsKey("include_referencing") == true && Convert.ToBoolean(arguments["include_referencing"]);

        //        var dependencies = await _genesysClient.GetArchitectDependenciesAsync();
        //        if (dependencies?.Objects == null || !dependencies.Objects.Any())
        //        {
        //            return "❌ **Nenhuma dependência encontrada no Architect**";
        //        }

        //        var filteredDependencies = dependencies.Objects.AsEnumerable();
        //        if (!string.IsNullOrEmpty(objectType))
        //        {
        //            filteredDependencies = filteredDependencies.Where(d => d.Type?.Equals(objectType, StringComparison.OrdinalIgnoreCase) == true);
        //        }

        //        if (!string.IsNullOrEmpty(objectId))
        //        {
        //            filteredDependencies = filteredDependencies.Where(d => d.Id == objectId);
        //        }

        //        var exportData = new
        //        {
        //            timestamp = DateTime.UtcNow,
        //            export_type = "architect_dependencies",
        //            object_type_filter = objectType,
        //            object_id_filter = objectId,
        //            include_referenced = includeReferenced,
        //            include_referencing = includeReferencing,
        //            total_objects = filteredDependencies.Count(),
        //            dependencies = filteredDependencies.Select(d => new
        //            {
        //                id = d.Id,
        //                name = d.Name,
        //                type = d.Type,
        //                version = d.Version,
        //                referenced_objects = includeReferenced ? d.ReferencedObjects : null,
        //                referencing_objects = includeReferencing ? d.ReferencingObjects : null
        //            })
        //        };

        //        return FormatExportData(exportData, exportFormat, "architect_dependencies");
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger?.LogError(ex, "Erro ao mapear dependências do Architect");
        //        return $"❌ **Erro ao mapear dependências do Architect**: {ex.Message}";
        //    }
        //}

        // Métodos de Workforce Management
        private async Task<string> GetWorkforceManagementUnits(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var unitId = arguments?.ContainsKey("unit_id") == true ? arguments["unit_id"].ToString() : null;
                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeSettings = arguments?.ContainsKey("include_settings") == true && Convert.ToBoolean(arguments["include_settings"]);

                var units = await _genesysClient.GetWorkforceManagementUnitsAsync();
                if (string.IsNullOrEmpty(units))
                {
                    return "❌ **Nenhuma unidade de gerenciamento encontrada**";
                }

                //var filteredUnits = units.Entities.AsEnumerable();
                //if (!string.IsNullOrEmpty(unitId))
                //{
                //    filteredUnits = filteredUnits.Where(u => u.Id == unitId);
                //}

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "workforce_management_units",
                //    total_units = filteredUnits.Count(),
                //    units = filteredUnits.Select(u => new
                //    {
                //        id = u.Id,
                //        name = u.Name,
                //        //description = u.Description,
                //        //version = u.Version,
                //        //date_created = u.DateCreated,
                //        //date_modified = u.DateModified,
                //       // modified_by = u.ModifiedBy,
                //        settings = includeSettings ? u.Settings : null
                //    })
                //};

                return units;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao consultar unidades de gerenciamento");
                return $"❌ **Erro ao consultar unidades de gerenciamento**: {ex.Message}";
            }
        }

        private async Task<string> GetQualityForms(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";

                var forms = await _genesysClient.GetQualityFormsAsync();
                if (string.IsNullOrEmpty(forms))
                {
                    return "❌ **Nenhum formulário de qualidade encontrado**";
                }

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "quality_forms",
                //    total_forms = forms.Entities.Count(),
                //    forms = forms.Entities.Select(f => new
                //    {
                //        id = f.Id,
                //        name = f.Name,
                //        modified_date = f.ModifiedDate,
                //        published = f.Published,
                //        context_id = f.ContextId,
                //        question_groups = f.QuestionGroups
                //    })
                //};

                return forms;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao consultar formulários de qualidade");
                return $"❌ **Erro ao consultar formulários de qualidade**: {ex.Message}";
            }
        }
        private async Task<string> GetOutboundCampaigns(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";

                var campaigns = await _genesysClient.GetOutboundCampaignsAsync();
                if (string.IsNullOrEmpty(campaigns))
                {
                    return "❌ **Nenhuma campanha outbound encontrada**";
                }

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "outbound_campaigns",
                //    total_count = campaigns.Total,
                //    campaigns = campaigns.Entities.Select(c => new
                //    {
                //        id = c.Id,
                //        name = c.Name,
                //        //status = c.Status,
                //        //dialer_config = c.DialerConfig,
                //        contact_list = c.ContactList,
                //        queue = c.Queue,
                //        edge_group = c.EdgeGroup,
                //        site = c.Site,
                //        //caller_name = c.CallerName,
                //        //caller_address = c.CallerAddress,
                //        //outbound_line_count = c.OutboundLineCount,
                //        //rule_sets = c.RuleSets,
                //        //skip_preview_disabled = c.SkipPreviewDisabled,
                //        //preview_time_out_seconds = c.PreviewTimeOutSeconds,
                //        //always_running = c.AlwaysRunning,
                //        //no_answer_timeout = c.NoAnswerTimeout,
                //        //call_analysis_response_set = c.CallAnalysisResponseSet,
                //        //caller_id = c.CallerId,
                //        //caller_id_name = c.CallerIdName,
                //        //contact_sorts = c.ContactSorts,
                //        //contact_sorts_within_time_zone = c.ContactSortsWithinTimeZone,
                //        division = c.Division
                //    })
                //};

                return campaigns;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao consultar campanhas outbound");
                return $"❌ **Erro ao consultar campanhas outbound**: {ex.Message}";
            }
        }

        private async Task<string> GetContactLists(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";

                var contactLists = await _genesysClient.GetContactListsAsync();
                if (string.IsNullOrEmpty(contactLists))
                {
                    return "❌ **Nenhuma lista de contatos encontrada**";
                }

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "contact_lists",
                //    total_count = contactLists.Total,
                //    contact_lists = contactLists.Entities.Select(cl => new
                //    {
                //        id = cl.Id,
                //        name = cl.Name,
                //        column_names = cl.ColumnNames,
                //        phone_columns = cl.PhoneColumns,
                //        import_status = cl.ImportStatus,
                //        size = cl.Size,
                //        //attempt_limits = cl.AttemptLimits,
                //        //automatic_time_zone_mapping = cl.AutomaticTimeZoneMapping,
                //        //zip_code_column_name = cl.ZipCodeColumnName,
                //        division = cl.Division
                //        //preview_mode_column_name = cl.PreviewModeColumnName,
                //        //preview_mode_accepted_values = cl.PreviewModeAcceptedValues
                //    })
                //};

                return contactLists;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao consultar listas de contatos");
                return $"❌ **Erro ao consultar listas de contatos**: {ex.Message}";
            }
        }
        private async Task<string> GetOutboundSequences(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";

                var sequences = await _genesysClient.GetOutboundSequencesAsync();
                if (string.IsNullOrEmpty(sequences))
                {
                    return "❌ **Nenhuma sequência outbound encontrada**";
                }

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "outbound_sequences",
                //    total_count = sequences.Total,
                //    sequences = sequences.Entities.Select(s => new
                //    {
                //        id = s.Id,
                //        name = s.Name,
                //        status = s.Status,
                //        repeat = s.Repeat,
                //        campaigns = s.Campaigns
                //       // division = s.Division
                //    })
                //};

                return sequences;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao consultar sequências outbound");
                return $"❌ **Erro ao consultar sequências outbound**: {ex.Message}";
            }
        }
        private async Task<string> GetPresenceDefinitions(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";

                var definitions = await _genesysClient.GetPresenceDefinitionsAsync();
                if (string.IsNullOrEmpty(definitions))
                {
                    return "❌ **Nenhuma definição de presença encontrada**";
                }

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "presence_definitions",
                //    total_count = definitions.Total,
                //    definitions = definitions.Entities.Select(d => new
                //    {
                //        id = d.Id,
                //        name = d.Name,
                //        language_labels = d.LanguageLabels,
                //        system_presence = d.SystemPresence,
                //        deactivated = d.Deactivated,
                //        primary = d.Primary,
                //        created_date = d.CreatedDate,
                //        created_by = d.CreatedBy?.Name,
                //        modified_date = d.ModifiedDate,
                //        modified_by = d.ModifiedBy?.Name,
                //        self_uri = d.SelfUri
                //    })
                //};

                return definitions;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao consultar definições de presença");
                return $"❌ **Erro ao consultar definições de presença**: {ex.Message}";
            }
        }

        private async Task<string> GetGamificationProfiles(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                {
                    return "❌ **Erro**: Cliente Genesys Cloud não configurado";
                }

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";

                var profiles = await _genesysClient.GetGamificationProfilesAsync();
                if (string.IsNullOrEmpty(profiles))
                {
                    return "❌ **Perfis de gamificação não encontrados**";
                }

                //var exportData = new
                //{
                //    timestamp = DateTime.UtcNow,
                //    export_type = "gamification_profiles",
                //    total_count = profiles.Total,
                //    profiles = profiles.Entities.Select(p => new
                //    {
                //        id = p.Id,
                //        name = p.Name,
                //        description = p.Description,
                //        active = p.Active,
                //        date_created = p.DateCreated,
                //        date_modified = p.DateModified,
                //        created_by = p.CreatedBy?.Name,
                //        modified_by = p.ModifiedBy?.Name,
                //        metrics_count = p.Metrics?.Count ?? 0
                //    })
                //};

                return profiles;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Erro ao consultar perfis de gamificação");
                return $"❌ **Erro ao consultar perfis de gamificação**: {ex.Message}";
            }
        }


        private async Task<string> GetConfigExportComplete(Dictionary<string, object>? arguments)
        {
            try
            {
                if (_genesysClient == null)
                    return "❌ **Erro**: Cliente Genesys não configurado";

                var exportFormat = arguments?.ContainsKey("export_format") == true ? arguments["export_format"].ToString() : "json";
                var includeDetails = arguments?.ContainsKey("include_details") == true && Convert.ToBoolean(arguments["include_details"]);

                // Executar todas as exportações em paralelo
                var tasks = new List<Task<object?>>
                {
                    Task.Run(async () => (object?)await _genesysClient.GetDivisionsAsync()),
                    Task.Run(async () => (object?)await _genesysClient.GetLocationsAsync()),
                    Task.Run(async () => (object?)await _genesysClient.GetGroupsAsync()),
                    Task.Run(async () => (object?)await _genesysClient.GetRolesAsync()),
                    Task.Run(async () => (object?)await _genesysClient.GetWrapupCodesAsync()),
                    Task.Run(async () => (object?)await _genesysClient.GetOrganizationAsync()),
                    Task.Run(async () => (object?)await _genesysClient.GetScriptsAsync())
                };

                var results = await Task.WhenAll(tasks);

                var completeExport = new
                {
                    timestamp = DateTime.UtcNow,
                    export_type = "complete_organizational_config",
                    summary = new
                    {
                        divisions_count = ((DivisionsResponse?)results[0])?.Total ?? 0,
                        locations_count = ((LocationsResponse?)results[1])?.Total ?? 0,
                        groups_count = ((GroupsResponse?)results[2])?.Total ?? 0,
                        roles_count = ((RolesResponse?)results[3])?.total ?? 0,
                        wrapup_codes_count = ((WrapupCodesResponse?)results[4])?.total ?? 0,
                        organization_name = ((OrganizationResponse?)results[5])?.name ?? "N/A",
                        scripts_count = ((ScriptsResponse?)results[6])?.Total ?? 0
                    },
                    data = includeDetails ? new
                    {
                        divisions = results[0],
                        locations = results[1],
                        groups = results[2],
                        roles = results[3],
                        wrapup_codes = results[4],
                        organization = results[5],
                        scripts = results[6]
                    } : null
                };

                return FormatExportData(completeExport, exportFormat, "complete_config_export");
            }
            catch (Exception ex)
            {
                return $"❌ **Erro na exportação completa**: {ex.Message}";
            }
        }
    }
}