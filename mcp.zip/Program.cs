using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Azure.Functions.Worker;
using MCPServer.Services;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureAppConfiguration((context, config) =>
    {
        config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
        config.AddJsonFile("genesys-config.json", optional: true, reloadOnChange: true);
        config.AddEnvironmentVariables();
    })
    .ConfigureServices((context, services) =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();


        // Registrar HttpClient
        services.AddHttpClient<GenesysCloudApiClient>();

        // Registrar servi�os
        services.AddSingleton<GenesysCloudApiClient>();
        services.AddSingleton<MCPService>(provider =>
        {
            var logger = provider.GetService<Microsoft.Extensions.Logging.ILogger<MCPService>>();
            var genesysClient = provider.GetService<GenesysCloudApiClient>();
            return new MCPService(logger, genesysClient);
        });
    })
    .Build();

host.Run();
