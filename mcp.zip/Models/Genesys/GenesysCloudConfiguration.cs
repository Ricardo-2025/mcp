using System.Text.Json;

namespace MCPServer.Models.Genesys
{
    public class GenesysCloudConfiguration
    {
        public string ClientId { get; set; } = string.Empty;
        public string ClientSecret { get; set; } = string.Empty;
        public string Environment { get; set; } = string.Empty;
        public string AuthUrl { get; set; } = string.Empty;
        public int TokenExpirationBuffer { get; set; } = 300;
    }

    public static class JsonSerializationOptions
    {
        public static readonly JsonSerializerOptions Default = new()
        {
            PropertyNameCaseInsensitive = true
        };
    }
}