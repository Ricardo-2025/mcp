using System.Text.Json.Serialization;

namespace MCPServer.Models.Genesys
{
    // Token Response
    public class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string? AccessToken { get; set; }

        [JsonPropertyName("token_type")]
        public string? TokenType { get; set; }

        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }
    }

    public class User
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Department { get; set; }
        public string? State { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public int? Version { get; set; }
    }

    public class UsersResponse
    {
        public List<User>? Entities { get; set; }
        public int? Total { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
    }

    public class Queue
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? State { get; set; }
        public Division? Division { get; set; }
        public int? Version { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public Dictionary<string, object>? MediaSettings { get; set; }
        public List<string>? RoutingRules { get; set; }
    }

    public class QueuesResponse
    {
        public List<Queue>? Entities { get; set; }
        public int? Total { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
    }

    public class Skill
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? State { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public int? Version { get; set; }
    }

    public class SkillsResponse
    {
        public List<Skill>? Entities { get; set; }
        public int? Total { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
    }

    public class UserSkill
    {
        public string? Id { get; set; }
        public string? SkillName { get; set; }
        public double? Proficiency { get; set; }
        public string? State { get; set; }
    }

    public class UserSkillsResponse
    {
        public List<UserSkill>? Entities { get; set; }
        public int? Total { get; set; }
    }

    public class Division
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
    }

    public class UserPresenceResponse
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Source { get; set; }
        public bool? Primary { get; set; }
        public string? PresenceDefinition { get; set; }
        public string? Message { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }

    // Classes para Campaigns
    public class CampaignsResponse
    {
        public List<Campaign>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class Campaign
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public int? Version { get; set; }
        public string? ContactList { get; set; }
        public Queue? Queue { get; set; }
        public string? DialingMode { get; set; }
        public string? Script { get; set; }
        public string? EdgeGroup { get; set; }
        public string? Site { get; set; }
        public string? CampaignStatus { get; set; }
        public List<string>? PhoneColumns { get; set; }
        public int? Priority { get; set; }
        public List<string>? ContactSorts { get; set; }
        public List<string>? NoAnswerTimeout { get; set; }
        public string? CallAnalysisResponseSet { get; set; }
        public string? CallerName { get; set; }
        public string? CallerAddress { get; set; }
        public int? OutboundLineCount { get; set; }
        public List<string>? RuleSets { get; set; }
        public bool? SkipPreviewDisabled { get; set; }
        public long? PreviewTimeOutSeconds { get; set; }
        public bool? AlwaysRunning { get; set; }
        public List<string>? ContactListFilters { get; set; }
        public Division? Division { get; set; }
        public string? SelfUri { get; set; }
    }

    public class CampaignStatsResponse
    {
        public string? CampaignId { get; set; }
        public Queue? Queue { get; set; }
        public CampaignStats? Stats { get; set; }
    }

    public class CampaignStats
    {
        public int? ContactRate { get; set; }
        public int? IdleAgents { get; set; }
        public int? RightPartyContacts { get; set; }
        public int? StoppedCalls { get; set; }
        public int? CompletedCalls { get; set; }
        public int? CallsPerAgent { get; set; }
        public int? LiveVoiceContacts { get; set; }
    }

    // Classes para Integrations
    public class IntegrationsResponse
    {
        public List<Integration>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class Integration
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public IntegrationType? IntegrationType { get; set; }
        public string? Notes { get; set; }
        public bool? IntendedState { get; set; }
        public Dictionary<string, object>? Config { get; set; }
        public string? ReportedState { get; set; }
        public Dictionary<string, string>? Attributes { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public User? CreatedBy { get; set; }
        public User? ModifiedBy { get; set; }
        public int? Version { get; set; }
        public string? SelfUri { get; set; }
    }

    public class IntegrationTypesResponse
    {
        public List<IntegrationType>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class IntegrationType
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Provider { get; set; }
        public string? Category { get; set; }
        public List<string>? Images { get; set; }
        public Dictionary<string, object>? ConfigPropertiesSchemaUri { get; set; }
        public Dictionary<string, object>? ConfigAdvancedSchemaUri { get; set; }
        public string? HelpUri { get; set; }
        public string? TermsOfServiceUri { get; set; }
        public string? VendorName { get; set; }
        public string? VendorWebsite { get; set; }
        public string? MarketplaceUri { get; set; }
        public string? FaqUri { get; set; }
        public string? PrivacyPolicyUri { get; set; }
        public string? SupportContactUri { get; set; }
        public string? SalesContactUri { get; set; }
        public string? HelpLinks { get; set; }
        public Dictionary<string, object>? Credentials { get; set; }
        public bool? NonInstallable { get; set; }
        public int? MaxInstances { get; set; }
        public string? UserPermissions { get; set; }
        public string? VendorOAuthClientIds { get; set; }
        public string? SelfUri { get; set; }
    }

    // Classes aprimoradas para Analytics
    public class ConversationDetailsResponse
    {
        public List<ConversationDetail>? Conversations { get; set; }
        public int? TotalHits { get; set; }
    }

    public class ConversationDetail
    {
        public string? ConversationId { get; set; }
        public DateTime? ConversationStart { get; set; }
        public DateTime? ConversationEnd { get; set; }
        public string? MediaType { get; set; }
        public List<Participant>? Participants { get; set; }
        public List<string>? Evaluations { get; set; }
        public List<string>? Surveys { get; set; }
        public Division? Division { get; set; }
    }

    public class Participant
    {
        public string? ParticipantId { get; set; }
        public string? ParticipantName { get; set; }
        public string? UserId { get; set; }
        public string? Purpose { get; set; }
        public DateTime? ParticipantStart { get; set; }
        public DateTime? ParticipantEnd { get; set; }
        public List<Session>? Sessions { get; set; }
    }

    public class Session
    {
        public string? SessionId { get; set; }
        public string? MediaType { get; set; }
        public DateTime? SessionStart { get; set; }
        public DateTime? SessionEnd { get; set; }
        public string? Direction { get; set; }
        public List<Segment>? Segments { get; set; }
    }

    public class Segment
    {
        public string? SegmentStart { get; set; }
        public string? SegmentEnd { get; set; }
        public string? QueueId { get; set; }
        public string? WrapUpCode { get; set; }
        public string? WrapUpNote { get; set; }
        public List<string>? WrapUpTags { get; set; }
        public string? ErrorCode { get; set; }
        public string? DisconnectType { get; set; }
        public string? SegmentType { get; set; }
        public string? RequestedRoutingUserIds { get; set; }
    }

    public class QueueObservationResponse
    {
        public List<QueueObservationDataContainer>? Results { get; set; }
    }

    public class QueueObservationDataContainer
    {
        public string? Group { get; set; }
        public List<QueueObservationData>? Data { get; set; }
    }

    public class QueueObservationData
    {
        public string? Interval { get; set; }
        public QueueMetrics? Metrics { get; set; }
    }

    public class QueueMetrics
    {
        public int? OWaiting { get; set; }
        public int? OInteracting { get; set; }
        public int? OOnQueueUsers { get; set; }
        public int? OOffQueueUsers { get; set; }
    }

    // Classes para APIs de Configura��o Organizacional
    public class DivisionsResponse
    {
        public List<DivisionInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class DivisionInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public bool? HomeDivision { get; set; }
        public List<string>? ObjectCounts { get; set; }
        public string? SelfUri { get; set; }
    }

    public class LocationsResponse
    {
        public List<LocationInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public string firstUri { get; set; }
        public string selfUri { get; set; }
        public string lastUri { get; set; }
        public int? PageCount { get; set; }
    }

    public class LocationInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        //public string? Description { get; set; }
        public Emergencynumber emergencyNumber { get; set; }
        public LocationAddress? Address { get; set; }
        public string? State { get; set; }
        public int version { get; set; }
        public bool addressVerified { get; set; }
        public string? SelfUri { get; set; }
        public Contactuser contactUser { get; set; }
        public string notes { get; set; }
        public bool addressStored { get; set; }
        //public string? FloorplanImage { get; set; }
        //public LocationAddressVerificationDetails? AddressVerificationDetails { get; set; }
        //public EmergencyNumber? EmergencyNumber { get; set; }

    }

    public class Emergencynumber
    {
        public string e164 { get; set; }
        public string number { get; set; }
        public string type { get; set; }
    }

    public class Contactuser
    {
        public string id { get; set; }
        public string selfUri { get; set; }
    }

    public class LocationAddress
    {
        public string? City { get; set; }
        public string? Country { get; set; }
        public string? CountryName { get; set; }
        public string? State { get; set; }
        public string? Street1 { get; set; }
        public string? ZipCode { get; set; }
    }

    public class LocationAddressVerificationDetails
    {
        public bool? Status { get; set; }
        public DateTime? DateFinished { get; set; }
        public DateTime? DateStarted { get; set; }
        public string? Service { get; set; }
    }

    public class EmergencyNumber
    {
        public string? E164 { get; set; }
        public string? Number { get; set; }
        public string? Type { get; set; }
    }

    public class GroupsResponse
    {
        public List<GroupInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class GroupInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public DateTime? DateModified { get; set; }
        public int? MemberCount { get; set; }
        public string? State { get; set; }
        public int? Version { get; set; }
        public string? Type { get; set; }
        public List<string>? Images { get; set; }
        public List<LocationAddress>? Addresses { get; set; }
        public List<Contact>? PhoneNumbers { get; set; }
        public List<Contact>? Emails { get; set; }
        public User? Owner { get; set; }
        public string? SelfUri { get; set; }
    }

    public class Contact
    {
        public string? Address { get; set; }
        public string? Display { get; set; }
        public string? Extension { get; set; }
        public string? AcceptsSMS { get; set; }
        public string? UserInput { get; set; }
    }

    public class RolesResponse
    {
        public List<RoleInfo>? Entities { get; set; }
        public int pageSize { get; set; }
        public int pageNumber { get; set; }
        public int total { get; set; }
        public string nextUri { get; set; }
        public string lastUri { get; set; }
        public string firstUri { get; set; }
        public string selfUri { get; set; }
        public int pageCount { get; set; }
    }

    public class RoleInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string defaultRoleId { get; set; }
        public string[] permissions { get; set; }
        public Permissionpolicy[] permissionPolicies { get; set; }
        public int userCount { get; set; }
        public string baseLicense { get; set; }
        public string[] addonLicenses { get; set; }
        public bool _base { get; set; }
        public bool _default { get; set; }
        public string selfUri { get; set; }
    }

    public class Permissionpolicy
    {
        public string domain { get; set; }
        public string entityName { get; set; }
        public string[] actionSet { get; set; }
        public bool allowConditions { get; set; }
        public Resourceconditionnode resourceConditionNode { get; set; }
    }

    public class Resourceconditionnode
    {
        public object[] operands { get; set; }
        public string conjunction { get; set; }
        public Term[] terms { get; set; }
    }

    public class Term
    {
        public string variableName { get; set; }
        public string _operator { get; set; }
        public Operand[] operands { get; set; }
        public object[] terms { get; set; }
    }

    public class Operand
    {
        public string value { get; set; }
        public string type { get; set; }
    }

    public class WrapupCodesResponse
    {
        public List<WrapupCodeInfo>? Entities { get; set; }
        public int pageSize { get; set; }
        public int pageNumber { get; set; }
        public int total { get; set; }
        public string lastUri { get; set; }
        public string firstUri { get; set; }
        public string selfUri { get; set; }
        public int pageCount { get; set; }
    }

    public class WrapupCodeInfo
    {
        public string id { get; set; }
        public string name { get; set; }
        public Division division { get; set; }
        public DateTime dateCreated { get; set; }
        public string createdBy { get; set; }
        public string selfUri { get; set; }
        public DateTime dateModified { get; set; }
        public string modifiedBy { get; set; }
    }
    public class OrganizationResponse
    {
        public string id { get; set; }
        public string name { get; set; }
        public string defaultLanguage { get; set; }
        public string defaultCountryCode { get; set; }
        public string thirdPartyOrgName { get; set; }
        public string domain { get; set; }
        public int version { get; set; }
        public string state { get; set; }
        public string defaultSiteId { get; set; }
        public string thirdPartyOrgId { get; set; }
        public bool deletable { get; set; }
        public bool voicemailEnabled { get; set; }
        public bool autoInvite { get; set; }
        public string productPlatform { get; set; }
        public string selfUri { get; set; }
        public Features features { get; set; }
    }

    public class Features
    {
        public bool chat { get; set; }
        public bool contactCenter { get; set; }
        public bool directory { get; set; }
        public bool informalPhotos { get; set; }
        public bool purecloud { get; set; }
        public bool purecloudVoice { get; set; }
        public bool realtimeCIC { get; set; }
        public bool unifiedCommunications { get; set; }
        public bool hipaa { get; set; }
        public bool pci { get; set; }
        public bool xmppFederation { get; set; }
    }

    public class ScriptsResponse
    {
        public List<ScriptInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class ScriptInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public Division? Division { get; set; }
        public int? VersionId { get; set; }
        public User? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public User? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public DateTime? PublishedDate { get; set; }
        public User? PublishedBy { get; set; }
        public string? SelfUri { get; set; }
    }


    // Classes para APIs do Architect
    public class PromptsResponse
    {
        public List<PromptInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class PromptInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public List<PromptResource>? Resources { get; set; }
        public User? CreatedBy { get; set; }
        public DateTime? DateCreated { get; set; }
        public User? ModifiedBy { get; set; }
        public DateTime? DateModified { get; set; }
        public string? SelfUri { get; set; }
    }

    public class PromptResource
    {
        public string? Language { get; set; }
        public string? MediaUri { get; set; }
        public string? Text { get; set; }
        public long? DurationSeconds { get; set; }
    }

    public class FlowsResponse
    {
        public List<FlowInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class FlowInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Type { get; set; }
        public Division? Division { get; set; }
        public bool? Published { get; set; }
        public FlowVersion? PublishedVersion { get; set; }
        public FlowVersion? CheckedInVersion { get; set; }
        public User? CreatedBy { get; set; }
        public DateTime? DateCreated { get; set; }
        public User? ModifiedBy { get; set; }
        public DateTime? DateModified { get; set; }
        public string? SelfUri { get; set; }
    }

    public class FlowVersion
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? CommitVersion { get; set; }
        public string? ConfigurationVersion { get; set; }
        public string? Type { get; set; }
        public bool? Secure { get; set; }
        public bool? Debug { get; set; }
        public User? CreatedBy { get; set; }
        public DateTime? DateCreated { get; set; }
        public User? ModifiedBy { get; set; }
        public DateTime? DateModified { get; set; }
        public string? SelfUri { get; set; }
    }

    public class DependenciesResponse
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }
        public List<DependencyObject>? ReferencedObjects { get; set; }
        public List<DependencyObject>? ReferencingObjects { get; set; }
    }

    public class DependencyObject
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }
        public string? SelfUri { get; set; }
    }

    public class SystemPromptsResponse
    {
        public List<SystemPromptInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class SystemPromptInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public List<SystemPromptResource>? Resources { get; set; }
        public string? SelfUri { get; set; }
    }

    public class SystemPromptResource
    {
        public string? Language { get; set; }
        public string? MediaUri { get; set; }
        public long? DurationSeconds { get; set; }
    }

    // Classes para Workforce Management
    public class ManagementUnitsResponse
    {
        public List<ManagementUnit>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class ManagementUnit
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public Division? Division { get; set; }
        public string? BusinessUnitId { get; set; }
        public DateTime? StartDayOfWeek { get; set; }
        public string? TimeZone { get; set; }
        public ManagementUnitSettings? Settings { get; set; }
        public string? SelfUri { get; set; }
    }

    public class ManagementUnitSettings
    {
        public bool? Adherence { get; set; }
        public bool? ShortTermForecasting { get; set; }
        public bool? TimeOffRequestSubmission { get; set; }
        public bool? ShiftTrading { get; set; }
    }

    public class SchedulesResponse
    {
        public List<ScheduleInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class ScheduleInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public bool? Published { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? ManagementUnitId { get; set; }
        public User? CreatedBy { get; set; }
        public DateTime? DateCreated { get; set; }
        public User? ModifiedBy { get; set; }
        public DateTime? DateModified { get; set; }
        public string? SelfUri { get; set; }
    }

    public class AdherenceResponse
    {
        public List<AdherenceInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class AdherenceInfo
    {
        public string? UserId { get; set; }
        public string? UserName { get; set; }
        public string? ManagementUnitId { get; set; }
        public string? ScheduledActivityCode { get; set; }
        public string? ActualActivityCode { get; set; }
        public DateTime? StartDate { get; set; }
        public int? LengthMinutes { get; set; }
        public string? AdherenceState { get; set; }
        public int? AdherencePercentage { get; set; }
    }

    public class ForecastsResponse
    {
        public List<ForecastInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class ForecastInfo
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public DateTime? WeekDate { get; set; }
        public int? WeekCount { get; set; }
        public string? TimeZone { get; set; }
        public User? CreatedBy { get; set; }
        public DateTime? DateCreated { get; set; }
        public User? ModifiedBy { get; set; }
        public DateTime? DateModified { get; set; }
        public string? SelfUri { get; set; }
    }

    public class TimeOffRequestsResponse
    {
        public List<TimeOffRequestInfo>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
    }

    public class TimeOffRequestInfo
    {
        public string? Id { get; set; }
        public User? User { get; set; }
        public bool? IsFullDayRequest { get; set; }
        public bool? MarkedAsRead { get; set; }
        public string? ActivityCodeId { get; set; }
        public string? Status { get; set; }
        public string? PartialDayStartDateTimes { get; set; }
        public List<string>? FullDayManagementUnitDates { get; set; }
        public int? DailyDurationMinutes { get; set; }
        public string? Notes { get; set; }
        public User? SubmittedBy { get; set; }
        public DateTime? SubmittedDate { get; set; }
        public User? ReviewedBy { get; set; }
        public DateTime? ReviewedDate { get; set; }
        public string? SelfUri { get; set; }
    }

    // Quality Management Models
    public class QualityEvaluationsResponse
    {
        public List<QualityEvaluation>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
        public string? SelfUri { get; set; }
    }

    public class QualityEvaluation
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? ConversationId { get; set; }
        public User? Agent { get; set; }
        public User? Evaluator { get; set; }
        public DateTime? EventTime { get; set; }
        public QualityEvaluationForm? EvaluationForm { get; set; }
        public string? Status { get; set; }
        public int? TotalScore { get; set; }
        public int? TotalCriticalScore { get; set; }
        public bool? AgentHasRead { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public DateTime? AssignedDate { get; set; }
        public DateTime? ChangedDate { get; set; }
        public string? SelfUri { get; set; }
    }

    public class QualityEvaluationForm
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? Published { get; set; }
        public string? ContextId { get; set; }
        public string? SelfUri { get; set; }
    }

    public class QualityFormsResponse
    {
        public List<QualityForm>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
        public string? SelfUri { get; set; }
    }

    public class QualityForm
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? Published { get; set; }
        public string? ContextId { get; set; }
        public List<string>? QuestionGroups { get; set; }
        public string? SelfUri { get; set; }
    }

    public class QualityCalibrationsResponse
    {
        public List<QualityCalibration>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
        public string? SelfUri { get; set; }
    }

    public class QualityCalibration
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public User? Calibrator { get; set; }
        public List<User>? Evaluators { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public string? Status { get; set; }
        public QualityEvaluationForm? EvaluationForm { get; set; }
        public string? SelfUri { get; set; }
    }

    // Conversations Models
    public class ConversationsResponse
    {
        public List<Conversation>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
        public string? SelfUri { get; set; }
    }

    public class Conversation
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string? Direction { get; set; }
        public List<ConversationParticipant>? Participants { get; set; }
        public string? State { get; set; }
        public int? Duration { get; set; }
        public string? SelfUri { get; set; }
    }

    public class ConversationParticipant
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Purpose { get; set; }
        public User? User { get; set; }
        public Queue? Queue { get; set; }
        public List<ConversationSession>? Sessions { get; set; }
    }

    public class ConversationSession
    {
        public string? Id { get; set; }
        public string? MediaType { get; set; }
        public string? Direction { get; set; }
        public DateTime? ConnectedTime { get; set; }
        public DateTime? DisconnectedTime { get; set; }
        public string? DisconnectType { get; set; }
        public string? Provider { get; set; }
    }

    //public class ConversationDetailsResponse
    //{
    //    public string? Id { get; set; }
    //    public string? Name { get; set; }
    //    public DateTime? StartTime { get; set; }
    //    public DateTime? EndTime { get; set; }
    //    public string? Direction { get; set; }
    //    public List<ConversationParticipant>? Participants { get; set; }
    //    public string? State { get; set; }
    //    public int? Duration { get; set; }
    //    public Dictionary<string, object>? Attributes { get; set; }
    //    public string? SelfUri { get; set; }
    //}

    public class ConversationMetricsResponse
    {
        public List<ConversationMetric>? Results { get; set; }
        public int? TotalHits { get; set; }
    }

    public class ConversationMetric
    {
        public string? Group { get; set; }
        public List<ConversationData>? Data { get; set; }
    }

    public class ConversationData
    {
        public string? Interval { get; set; }
        public ConversationStats? Stats { get; set; }
    }

    public class ConversationStats
    {
        public int? Count { get; set; }
        public double? Sum { get; set; }
        public double? Min { get; set; }
        public double? Max { get; set; }
        public double? Average { get; set; }
    }

    // Recording Models
    public class RecordingsResponse
    {
        public List<Recording>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public int? PageCount { get; set; }
        public string? SelfUri { get; set; }
    }

    public class Recording
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? ConversationId { get; set; }
        public string? Path { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string? Media { get; set; }
        public List<RecordingAnnotation>? Annotations { get; set; }
        public RecordingFileState? FileState { get; set; }
        public string? RestoreExpirationTime { get; set; }
        public string? ArchiveDate { get; set; }
        public string? DeleteDate { get; set; }
        public long? MaxAllowedRestorationsForOrg { get; set; }
        public long? RemainingRestorationsAllowedForOrg { get; set; }
        public string? SessionId { get; set; }
        public List<User>? Users { get; set; }
        public string? RecordingFileRole { get; set; }
        public string? RecordingErrorStatus { get; set; }
        public DateTime? CreationTime { get; set; }
        public string? SelfUri { get; set; }
    }

    public class RecordingAnnotation
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }
        public string? Location { get; set; }
        public long? DurationMs { get; set; }
        public long? AbsoluteLocation { get; set; }
        public DateTime? RecordingLocation { get; set; }
        public User? User { get; set; }
        public string? Description { get; set; }
    }

    public class RecordingFileState
    {
        public string? State { get; set; }
        public DateTime? RestoreExpirationTime { get; set; }
    }

    public class RecordingMetadataResponse
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? ConversationId { get; set; }
        public string? Path { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string? Media { get; set; }
        public List<RecordingAnnotation>? Annotations { get; set; }
        public Dictionary<string, object>? Metadata { get; set; }
        public string? SelfUri { get; set; }
    }

    public class RecordingTranscriptionResponse
    {
        public string? Id { get; set; }
        public string? RecordingId { get; set; }
        public List<TranscriptionSegment>? Transcripts { get; set; }
        public string? Confidence { get; set; }
        public DateTime? DateCreated { get; set; }
        public string? SelfUri { get; set; }
    }

    public class TranscriptionSegment
    {
        public string? Text { get; set; }
        public double? Confidence { get; set; }
        public long? OffsetMs { get; set; }
        public long? DurationMs { get; set; }
        public string? Channel { get; set; }
    }

    // Outbound Models
    public class OutboundCampaignsResponse
    {
        public List<OutboundCampaign>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int? PageCount { get; set; }
    }

    public class OutboundCampaign
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public int? Version { get; set; }
        public ContactList? ContactList { get; set; }
        public Queue? Queue { get; set; }
        public DialerConfig? DialingMode { get; set; }
        //public Script? Script { get; set; }
        public EdgeGroup? EdgeGroup { get; set; }
        public Site? Site { get; set; }
        public CampaignStatus? CampaignStatus { get; set; }
        public PhoneColumn? PhoneColumns { get; set; }
        public int? Priority { get; set; }
        public List<ContactListFilter>? ContactListFilters { get; set; }
        public Division? Division { get; set; }
        public string? SelfUri { get; set; }
    }

    public class ContactListsResponse
    {
        public List<ContactList>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int? PageCount { get; set; }
    }

    public class ContactList
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public int? Version { get; set; }
        public Division? Division { get; set; }
        public List<string>? ColumnNames { get; set; }
        public List<PhoneColumn>? PhoneColumns { get; set; }
        public ImportStatus? ImportStatus { get; set; }
        public long? Size { get; set; }
        public string? SelfUri { get; set; }
    }

    public class OutboundSequencesResponse
    {
        public List<OutboundSequence>? Entities { get; set; }
        public int? PageSize { get; set; }
        public int? PageNumber { get; set; }
        public long? Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int? PageCount { get; set; }
    }

    public class OutboundSequence
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public int? Version { get; set; }
        public List<OutboundCampaign>? Campaigns { get; set; }
        public string? CurrentCampaign { get; set; }
        public string? Status { get; set; }
        public bool? Repeat { get; set; }
        public string? SelfUri { get; set; }
    }

    public class DialerConfig
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? ConfigType { get; set; }
        public string? LinesToDial { get; set; }
        public string? LinesPerAgent { get; set; }
        public string? AgentOccupancyPercentage { get; set; }
        public string? SelfUri { get; set; }
    }

    public class CampaignStatus
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? SelfUri { get; set; }
    }

    public class PhoneColumn
    {
        public string? ColumnName { get; set; }
        public string? Type { get; set; }
        public string? CallableTimeColumn { get; set; }
    }

    public class ContactListFilter
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public ContactList? ContactList { get; set; }
        public List<string>? Clauses { get; set; }
        public string? FilterType { get; set; }
        public string? SelfUri { get; set; }
    }

    public class ImportStatus
    {
        public string? ImportState { get; set; }
        public long? TotalRecords { get; set; }
        public long? CompletedRecords { get; set; }
        public long? PercentageComplete { get; set; }
        public long? FailureCount { get; set; }
    }

    public class EdgeGroup
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public int? Version { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public string? State { get; set; }
        public string? SelfUri { get; set; }
    }

    public class Site
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public int? Version { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public string? State { get; set; }
        public string? SelfUri { get; set; }
    }

    // Analytics API Models
    public class AnalyticsReportsResponse
    {
        public List<AnalyticsReport>? Entities { get; set; }
        public int Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int PageCount { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
    }

    public class AnalyticsReport
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? ReportType { get; set; }
        public string? Status { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string? CreatedBy { get; set; }
        public string? ModifiedBy { get; set; }
        public List<string>? Columns { get; set; }
        public Dictionary<string, object>? Filters { get; set; }
        public string? TimeZone { get; set; }
        public string? Interval { get; set; }
        public string? SelfUri { get; set; }
    }

    public class AnalyticsMetricsResponse
    {
        public List<AnalyticsMetric>? Entities { get; set; }
        public int Total { get; set; }
        public string? SelfUri { get; set; }
    }

    public class AnalyticsMetric
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? DisplayName { get; set; }
        public string? Description { get; set; }
        public string? DataType { get; set; }
        public string? UnitType { get; set; }
        public string? UnitDefinition { get; set; }
        public List<string>? Dimensions { get; set; }
        public bool? IsActive { get; set; }
        public string? SelfUri { get; set; }
    }

    public class AnalyticsDataResponse
    {
        public List<Dictionary<string, object>>? Data { get; set; }
        public List<string>? Columns { get; set; }
        public int TotalRows { get; set; }
        public string? ReportId { get; set; }
        public DateTime? GeneratedDate { get; set; }
        public string? Status { get; set; }
        public string? SelfUri { get; set; }
    }

    // Presence API Models
    public class PresenceDefinitionsResponse
    {
        public List<PresenceDefinition>? Entities { get; set; }
        public int Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int PageCount { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
    }

    public class PresenceDefinition
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? LanguageLabels { get; set; }
        public string? SystemPresence { get; set; }
        public bool? Deactivated { get; set; }
        public bool? Primary { get; set; }
        public DateTime? CreatedDate { get; set; }
        public User? CreatedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public User? ModifiedBy { get; set; }
        public string? SelfUri { get; set; }
    }

    //public class UserPresenceResponse
    //{
    //    public string? Id { get; set; }
    //    public string? Name { get; set; }
    //    public string? Source { get; set; }
    //    public bool? Primary { get; set; }
    //    public PresenceDefinition? PresenceDefinition { get; set; }
    //    public string? Message { get; set; }
    //    public DateTime? ModifiedDate { get; set; }
    //    public string? SelfUri { get; set; }
    //}

    public class PresenceHistoryResponse
    {
        public List<PresenceHistory>? Entities { get; set; }
        public int Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int PageCount { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
    }

    public class PresenceHistory
    {
        public string? Id { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public PresenceDefinition? PresenceDefinition { get; set; }
        public string? Source { get; set; }
        public string? Message { get; set; }
        public User? ModifiedBy { get; set; }
    }

    // Gamification API Models
    public class GamificationProfilesResponse
    {
        public List<GamificationProfile>? Entities { get; set; }
        public int Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int PageCount { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
    }

    public class GamificationProfile
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public bool? Active { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public User? CreatedBy { get; set; }
        public User? ModifiedBy { get; set; }
        public List<GamificationMetric>? Metrics { get; set; }
        public string? SelfUri { get; set; }
    }

    public class GamificationMetricsResponse
    {
        public List<GamificationMetric>? Entities { get; set; }
        public int Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int PageCount { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
    }

    public class GamificationMetric
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? DisplayName { get; set; }
        public string? Description { get; set; }
        public string? MetricType { get; set; }
        public string? UnitType { get; set; }
        public double? Value { get; set; }
        public double? Target { get; set; }
        public double? Percentage { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public string? SelfUri { get; set; }
    }

    public class GamificationLeaderboardResponse
    {
        public List<GamificationLeaderboardEntry>? Entities { get; set; }
        public int Total { get; set; }
        public string? SelfUri { get; set; }
        public string? FirstUri { get; set; }
        public string? LastUri { get; set; }
        public string? NextUri { get; set; }
        public string? PreviousUri { get; set; }
        public int PageCount { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
    }

    public class GamificationLeaderboardEntry
    {
        public string? UserId { get; set; }
        public string? UserName { get; set; }
        public int? Rank { get; set; }
        public double? Score { get; set; }
        public List<GamificationMetric>? Metrics { get; set; }
        public DateTime? LastUpdated { get; set; }
    }



}