using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace MCPServer.Models
{
    // Modelos para Tools
    public class Tool
    {
        [JsonProperty("name")]
        [Required]
        public string Name { get; set; } = string.Empty;

        [JsonProperty("description")]
        public string? Description { get; set; }

        [JsonProperty("inputSchema")]
        public ToolInputSchema InputSchema { get; set; } = new();
    }

    public class ToolInputSchema
    {
        [JsonProperty("type")]
        public string Type { get; set; } = "object";

        [JsonProperty("properties")]
        public Dictionary<string, object>? Properties { get; set; }

        [JsonProperty("required")]
        public string[]? Required { get; set; }
    }

    public class ListToolsResult
    {
        [JsonProperty("tools")]
        public Tool[] Tools { get; set; } = Array.Empty<Tool>();
    }

    public class CallToolParams
    {
        [JsonProperty("name")]
        [Required]
        public string Name { get; set; } = string.Empty;

        [JsonProperty("arguments")]
        public Dictionary<string, object>? Arguments { get; set; }
    }

    public class CallToolResult
    {
        [JsonProperty("content")]
        public ToolContent[] Content { get; set; } = Array.Empty<ToolContent>();

        [JsonProperty("isError")]
        public bool IsError { get; set; }
    }

    public class ToolContent
    {
        [JsonProperty("type")]
        public string Type { get; set; } = "text";

        [JsonProperty("text")]
        public string? Text { get; set; }
    }

    // Modelos para Resources
    public class Resource
    {
        [JsonProperty("uri")]
        [Required]
        public string Uri { get; set; } = string.Empty;

        [JsonProperty("name")]
        public string? Name { get; set; }

        [JsonProperty("description")]
        public string? Description { get; set; }

        [JsonProperty("mimeType")]
        public string? MimeType { get; set; }
    }

    public class ListResourcesResult
    {
        [JsonProperty("resources")]
        public Resource[] Resources { get; set; } = Array.Empty<Resource>();
    }

    public class ReadResourceParams
    {
        [JsonProperty("uri")]
        [Required]
        public string Uri { get; set; } = string.Empty;
    }

    public class ReadResourceResult
    {
        [JsonProperty("contents")]
        public ResourceContent[] Contents { get; set; } = Array.Empty<ResourceContent>();
    }

    public class ResourceContent
    {
        [JsonProperty("uri")]
        public string Uri { get; set; } = string.Empty;

        [JsonProperty("mimeType")]
        public string? MimeType { get; set; }

        [JsonProperty("text")]
        public string? Text { get; set; }

        [JsonProperty("blob")]
        public string? Blob { get; set; }
    }

    // Modelos para Prompts
    public class Prompt
    {
        [JsonProperty("name")]
        [Required]
        public string Name { get; set; } = string.Empty;

        [JsonProperty("description")]
        public string? Description { get; set; }

        [JsonProperty("arguments")]
        public PromptArgument[]? Arguments { get; set; }
    }

    public class PromptArgument
    {
        [JsonProperty("name")]
        [Required]
        public string Name { get; set; } = string.Empty;

        [JsonProperty("description")]
        public string? Description { get; set; }

        [JsonProperty("required")]
        public bool Required { get; set; }
    }

    public class ListPromptsResult
    {
        [JsonProperty("prompts")]
        public Prompt[] Prompts { get; set; } = Array.Empty<Prompt>();
    }

    public class GetPromptParams
    {
        [JsonProperty("name")]
        [Required]
        public string Name { get; set; } = string.Empty;

        [JsonProperty("arguments")]
        public Dictionary<string, string>? Arguments { get; set; }
    }

    public class GetPromptResult
    {
        [JsonProperty("description")]
        public string? Description { get; set; }

        [JsonProperty("messages")]
        public PromptMessage[] Messages { get; set; } = Array.Empty<PromptMessage>();
    }

    public class PromptMessage
    {
        [JsonProperty("role")]
        public string Role { get; set; } = "user";

        [JsonProperty("content")]
        public PromptContent Content { get; set; } = new();
    }

    public class PromptContent
    {
        [JsonProperty("type")]
        public string Type { get; set; } = "text";

        [JsonProperty("text")]
        public string? Text { get; set; }
    }
}