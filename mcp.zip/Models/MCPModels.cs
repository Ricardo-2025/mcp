using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace MCPServer.Models
{
    // Modelo base para requisições MCP
    public class MCPRequest
    {
        [JsonProperty("jsonrpc")]
        public string JsonRpc { get; set; } = "2.0";

        [JsonProperty("id")]
        public string? Id { get; set; }

        [JsonProperty("method")]
        [Required]
        public string Method { get; set; } = string.Empty;

        [JsonProperty("params")]
        public object? Params { get; set; }
    }

    // Modelo base para respostas MCP
    public class MCPResponse
    {
        [JsonProperty("jsonrpc")]
        public string JsonRpc { get; set; } = "2.0";

        [JsonProperty("id")]
        public string? Id { get; set; }

        [JsonProperty("result")]
        public object? Result { get; set; }

        [JsonProperty("error")]
        public MCPError? Error { get; set; }
    }

    // Modelo para erros MCP
    public class MCPError
    {
        [JsonProperty("code")]
        public int Code { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; } = string.Empty;

        [JsonProperty("data")]
        public object? Data { get; set; }
    }

    // Modelo para inicialização do servidor
    public class InitializeParams
    {
        [JsonProperty("protocolVersion")]
        public string ProtocolVersion { get; set; } = "2024-11-05";

        [JsonProperty("capabilities")]
        public ClientCapabilities Capabilities { get; set; } = new();

        [JsonProperty("clientInfo")]
        public ClientInfo ClientInfo { get; set; } = new();
    }

    public class ClientCapabilities
    {
        [JsonProperty("roots")]
        public RootsCapability? Roots { get; set; }

        [JsonProperty("sampling")]
        public object? Sampling { get; set; }
    }

    public class RootsCapability
    {
        [JsonProperty("listChanged")]
        public bool ListChanged { get; set; }
    }

    public class ClientInfo
    {
        [JsonProperty("name")]
        public string Name { get; set; } = string.Empty;

        [JsonProperty("version")]
        public string Version { get; set; } = string.Empty;
    }

    // Modelo para resposta de inicialização
    public class InitializeResult
    {
        [JsonProperty("protocolVersion")]
        public string ProtocolVersion { get; set; } = "2024-11-05";

        [JsonProperty("capabilities")]
        public ServerCapabilities Capabilities { get; set; } = new();

        [JsonProperty("serverInfo")]
        public ServerInfo ServerInfo { get; set; } = new();
    }

    public class ServerCapabilities
    {
        [JsonProperty("logging")]
        public object? Logging { get; set; }

        [JsonProperty("prompts")]
        public PromptsCapability? Prompts { get; set; }

        [JsonProperty("resources")]
        public ResourcesCapability? Resources { get; set; }

        [JsonProperty("tools")]
        public ToolsCapability? Tools { get; set; }
    }

    public class PromptsCapability
    {
        [JsonProperty("listChanged")]
        public bool ListChanged { get; set; }
    }

    public class ResourcesCapability
    {
        [JsonProperty("subscribe")]
        public bool Subscribe { get; set; }

        [JsonProperty("listChanged")]
        public bool ListChanged { get; set; }
    }

    public class ToolsCapability
    {
        [JsonProperty("listChanged")]
        public bool ListChanged { get; set; }
    }

    public class ServerInfo
    {
        [JsonProperty("name")]
        public string Name { get; set; } = "MCP Server Azure Functions";

        [JsonProperty("version")]
        public string Version { get; set; } = "1.0.0";
    }
}